<?php
// db_config.php

// $servername = "localhost"; 
// $username_db = "pais3642_admLuiz"; 
// $password_db = "pYdZJu3=IV33";    
// $dbname = "pais3642_portfolio_blog";


$servername = "localhost"; // ou 127.0.0.1
$username_db = "root";     // Usuário padrão do XAMPP
$password_db = "";         // Senha padrão do XAMPP é vazia
$dbname = "pais3642_portfolio_blog"; // O nome do banco que você criou no Passo 3.2

?>
