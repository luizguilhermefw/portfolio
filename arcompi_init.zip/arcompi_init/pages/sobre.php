<?php require __DIR__ . '/../partials/head.php'; ?>
<?php require __DIR__ . '/../partials/header.php'; ?>

<div class="page-sobre">
    <main class="container">

        <section class="about-hero text-center">
            <h1 class="display-4">Sobre a Arcompi</h1>
            <p class="lead"><span class="experience-highlight">Há mais de 13 anos</span> oferecendo soluções completas e eficientes em ar comprimido para a indústria.</p>
        </section>

        <section class="about-section history-section">
            <div class="history-layout">
                <div class="history-image">
                    <img src="/arcompi_init/assets/img/imghead/arcompifrente.webp" class="img-fluid" alt="Frente da Arcompi">
                </div>
                <div class="history-content">
                    <h2>Nossa <br>História</h2>
                    <p>Fundada com a visão de ser referência em sistemas de ar comprimido, a Arcompi nasceu da paixão por tecnologia e da vontade de oferecer um serviço de excelência. Ao longo de nossa trajetória, construímos uma reputação sólida baseada na confiança, na qualidade técnica e no compromisso com os resultados de nossos clientes. Cada projeto é uma oportunidade de reafirmar nossa dedicação e de superar novas expectativas.</p>
                </div>
            </div>
        </section>

        <section class="about-section values-section">
            <div class="values-grid">
                <div class="value-card">
                    <h3>Missão</h3>
                    <p>Prover soluções em ar comprimido que otimizem processos industriais, garantindo máxima eficiência energética, segurança operacional e um atendimento ágil e especializado.</p>
                </div>
                <div class="value-card">
                    <h3>Visão</h3>
                    <p>Ser a principal parceira estratégica para indústrias na região, reconhecida pela inovação, confiabilidade de nossos serviços e pelo impacto positivo na produtividade de nossos clientes.</p>
                </div>
                <div class="value-card">
                    <h3>Valores</h3>
                    <ul>
                        <li><strong>Qualidade:</strong> Excelência em cada produto e serviço.</li>
                        <li><strong>Segurança:</strong> Prioridade máxima em todas as operações.</li>
                        <li><strong>Compromisso:</strong> Parceria e dedicação ao sucesso do cliente.</li>
                        <li><strong>Inovação:</strong> Busca contínua por tecnologias de ponta.</li>
                    </ul>
                </div>
            </div>
        </section>

        <section class="about-section structure-section text-center">
            <h2>Nossa Estrutura</h2>
            <p class="section-lead">Contamos com uma estrutura moderna e equipe qualificada para atender às mais diversas demandas.</p>
            <div class="structure-gallery">
                <div class="gallery-item">
                    <img src="/arcompi_init/assets/img/imghead/arcompiatendimento.webp" alt="Atendimento Arcompi">
                </div>
                <div class="gallery-item">
                    <img src="/arcompi_init/assets/img/imghead/arcompimanutencao.webp" alt="Manutenção Arcompi">
                </div>
                <div class="gallery-item">
                    <img src="/arcompi_init/assets/img/imghead/arcompiguincho.webp" alt="Guincho Arcompi">
                </div>
            </div>
        </section>

        <section class="about-section clients-section text-center">
            <h2>Confiança que Gera Resultados</h2>
            <p class="section-lead">Temos a honra de atender algumas das maiores e mais respeitadas indústrias da região.</p>
            <div class="client-logos-container">
                <img src="/arcompi_init/assets/img/logoclientes/logo-brf.webp" alt="Logo BRF">
                <img src="/arcompi_init/assets/img/logoclientes/logo-coopavel.webp" alt="Logo Coopavel">
                <img src="/arcompi_init/assets/img/logoclientes/logo-copagril.webp" alt="Logo Copagril">
                <img src="/arcompi_init/assets/img/logoclientes/logo-friella.webp" alt="Logo Friella">
            </div>
        </section>

        <section class="about-section cta-section-sobre text-center">
            <h2>Pronto para Otimizar seu Negócio?</h2>
            <p class="section-lead">Nossa equipe de especialistas está pronta para ajudar você a encontrar a solução ideal em ar comprimido.</p>
            <a href="/arcompi_init/contato" class="btn btn-primary btn-lg">Fale Conosco Agora</a>
        </section>

    </main>
</div>

<?php require __DIR__ . '/../partials/footer.php'; ?>