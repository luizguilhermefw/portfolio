<?php require __DIR__.'/../partials/head.php'; ?>
<?php require __DIR__.'/../partials/header.php'; ?>
<main>
  <section class="banner-carousel" aria-label="Destaques e anúncios">
    <div class="banner-thumbs">
      <div class="thumb-track" data-slider data-interval="4500">
        <?php
        // Pasta das imagens
        $imgDir = __DIR__ . '/../assets/img/imghead/';
        // Links e tags para cada imagem
        $links = [
          ['url' => BASE . '/auditoria', 'label' => 'Auditoria móvel', 'tag' => 'Auditoria', 'img' => 'auditoria.webp'],
          ['url' => BASE . '/servicos', 'label' => 'Assistência Técnica e Manutenção', 'tag' => 'Autorizada', 'img' => 'arcompimanutencao.webp'],
          ['url' => BASE . '/servicos', 'label' => 'Venda e Locação', 'tag' => 'Venda & Locação', 'img' => 'arcompifrente.webp'],
          ['url' => BASE . '/servicos', 'label' => 'Consultoria', 'tag' => 'Consultoria', 'img' => 'arcompiatendimento.webp'],
          ['url' => BASE . '/servicos', 'label' => 'Planos e Serviços', 'tag' => 'Planos', 'img' => 'arcompi.jpeg']
        ];
        // Listar arquivos na pasta
        $files = [];
        if (is_dir($imgDir)) {
          $files = array_filter(scandir($imgDir), function($file) {
            return !in_array($file, ['.', '..']) && in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), ['jpg', 'jpeg', 'png', 'webp']);
          });
        }
        // Criar thumbs com as imagens encontradas
        foreach ($files as $i => $file) {
          $link = $links[$i % count($links)]; 
          echo '<a class="thumb" href="' . $link['url'] . '" aria-label="' . $link['label'] . '">';
          echo '<img src="' . BASE . '/assets/img/imghead/' . $file . '" alt="' . $link['label'] . '" loading="lazy" />';
          echo '<div class="thumb-overlay"><h3>' . $link['label'] . '</h3></div>';
          echo '</a>';
        }
        ?>
      </div>
    </div>
  </section>
  <section id="hero" class="hero">
  <canvas class="bg-canvas" id="hero-canvas" data-effect="airflow" aria-hidden="true"></canvas>
    <div class="container hero-inner">
    <div class="hero-copy">
  <h1>Há mais de 13<br>anos no mercado</h1>
        <p>Especialistas em ar comprimido: equipamentos, instalação, auditoria e manutenção autorizada.</p>
        <div class="actions">
          <a class="btn btn-primary" href="<?= BASE ?>/contato">Solicitar orçamento</a>
          <a class="btn btn-ghost" href="<?= BASE ?>/auditoria">Conhecer auditoria</a>
        </div>
      </div>
    </div>
    <a href="#o-que-fazemos" class="scroll-indicator" aria-label="Rolar para a próxima seção"></a>
  </section>

  <section id="o-que-fazemos" class="accent-turquoise services-highlight">
  <canvas class="bg-canvas-right" id="services-canvas" data-canvas="services" data-effect="tris-left" data-density="1" aria-hidden="true"></canvas>
    <div class="container container-wide">
      <h2>Nossos Serviços</h2>
      <div class="services-grid">
  <article id="plano-servico" class="card service-card">
          <div class="card-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
          </div>
          <h3>Plano de serviço (peças e serviços)</h3>
          <div class="chips">
            <span class="chip">Plano</span><span class="chip">Preditivo</span><span class="chip">Corretivo</span>
          </div>
          <div class="collapsible is-collapsed">
            <div class="collapsible-inner">
          <ul class="list-check">
            <li>Visita técnica de inspeção mensal</li>
            <li>Revisões preditivas anuais</li>
            <li>Manutenções programadas</li>
            <li>Análise de óleo</li>
            <li>Análise de vibração</li>
            <li>Lubrificação dos motores elétricos</li>
            <li>Desconto em locação de equipamentos</li>
            <li>Desconto em serviço corretivo</li>
            <li>Desconto em demais auditorias</li>
          </ul>
            </div>
            <button type="button" class="reveal-toggle" aria-expanded="false">Ver mais</button>
          </div>
          <a class="card-link" href="<?= BASE ?>/servicos">Saiba mais</a>
        </article>

  <article id="analise-vibracao" class="card service-card">
          <div class="card-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
          </div>
          <h3>Análise de Vibração</h3>
          <ul class="list-check">
            <li>Diagnóstico preditivo de manutenção</li>
            <li>Análise de motores elétricos</li>
            <li>Antecipação de riscos e falhas</li>
            <li>Permite programação de paradas</li>
          </ul>
          <div class="diff-box">
            <span class="badge">Diferencial Arcompi</span>
            <ul>
              <li>Análise de unidade compressora</li>
              <li>Análise especializada em compressores</li>
              <li>Laudo com informações por equipamento</li>
            </ul>
          </div>
          <a class="card-link" href="<?= BASE ?>/auditoria">Saiba mais</a>
        </article>

  <article id="analise-oleo" class="card service-card">
          <div class="card-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
          </div>
          <h3>Análise de Óleo</h3>
          <ul class="list-check">
            <li>Diagnóstico preditivo de manutenção</li>
            <li>Análise dos componentes internos do equipamento</li>
            <li>Identificação de desgastes e envernizamentos</li>
            <li>Antecipação de riscos e falhas</li>
            <li>Permite programação de paradas</li>
          </ul>
          <div class="diff-box">
            <span class="badge">Diferencial Arcompi</span>
            <ul>
              <li>Análise especializada em compressores</li>
              <li>Laudo com informações por equipamento</li>
            </ul>
          </div>
          <a class="card-link" href="<?= BASE ?>/auditoria">Saiba mais</a>
        </article>

  <article id="intellisurvey" class="card service-card">
          <div class="card-icon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3h18v4H3zM3 10h18v11H3z"></path></svg>
          </div>
          <h3>Intellisurvey & Caça vazamentos</h3>
          <ul class="list-check">
            <li>Análise de desempenho dos equipamentos (Ingersoll Rand)</li>
            <li>Caça vazamentos</li>
            <li>Análise de desperdício por vazamentos (Ingersoll Rand)</li>
          </ul>
          <a class="card-link" href="<?= BASE ?>/auditoria">Saiba mais</a>
        </article>
      </div>
    </div>
    <a href="#por-que-escolher" class="scroll-indicator" aria-label="Rolar para a próxima seção"></a>
  </section>

  <section id="por-que-escolher" class="trust accent-turquoise">
  <canvas class="bg-canvas-left" id="trust-canvas" data-canvas="trust" data-effect="tris-right" data-density="1" aria-hidden="true"></canvas>
    <div class="container">
      <h2>Por que escolher a Arcompi</h2>
      <p class="section-lead">Soluções completas em ar comprimido com foco em eficiência, economia e confiabilidade — do projeto à assistência autorizada.</p>
      <div class="grid-benefits">
        <article class="benefit-card">
          <div class="benefit-icon" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"></path></svg>
          </div>
          <h3>Arcompi Compressores</h3>
          <p>Com foco na eficiência energética, a Arcompi estruturou um departamento exclusivo em auditorias em ar comprimido industrial, agora sua empresa pode contar com nossos profissionais.</p>
        </article>
        <article class="benefit-card">
          <div class="benefit-icon" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="5" x2="5" y2="19"></line><circle cx="7" cy="7" r="3"></circle><circle cx="17" cy="17" r="3"></circle></svg>
          </div>
          <h3>Economize</h3>
          <p>A melhor forma de economizar é com certeza cumprindo o plano de manutenção indicado pelo fabricante, agende já a manutenção do seu equipamento com nossa equipe.</p>
        </article>
        <article class="benefit-card">
          <div class="benefit-icon" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M9 12l2 2 4-4"></path></svg>
          </div>
          <h3>Assistência Técnica Autorizada</h3>
          <p>Você já conhece nossa linha de produtos? Trabalhamos com componentes para automação de referência, nossas marcas estão entre as melhores no mercado. Tudo isso para trazer a você um produto de alta qualidade!</p>
        </article>
        <article class="benefit-card">
          <div class="benefit-icon" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
          </div>
          <h3>Serviço de Auditoria</h3>
          <p>Com o nosso serviço de auditoria, podemos oferecer dados detalhados e informações que podem transformar seu sistema de ar comprimido gerando economia.</p>
        </article>
      </div>
      
      <div id="resultados" class="trust-stats">
        <h3>Resultados em números</h3>
        <div class="stats grid-4">
          <div class="stat">
            <div class="stat-value" data-count="120">0</div>
            <div class="stat-label">Projetos entregues</div>
          </div>
          <div class="stat">
            <div class="stat-value" data-count="28">0</div>
            <div class="stat-label">até % de economia</div>
          </div>
          <div class="stat">
            <div class="stat-value" data-count="15">0</div>
            <div class="stat-label">anos de experiência</div>
          </div>
          <div class="stat">
            <div class="stat-value" data-count="24">0</div>
            <div class="stat-label">h SLA manutenção</div>
          </div>
        </div>
      </div>
    </div>
    <a href="#clientes-e-parceiros" class="scroll-indicator" aria-label="Rolar para a próxima seção"></a>
  </section>

<section id="clientes-e-parceiros">
    <div class="container">
      <h2>Distribuidores Autorizados</h2>
      <div class="logos">
        <img src="<?= BASE ?>/assets/img/autorizados/micro_automacao.webp" alt="Micro-Automação"/>
        <img src="<?= BASE ?>/assets/img/autorizados/ingersoll_rand-1.webp" alt="Ingersoll-Rand"/>
      </div>
    </div>
  <a href="#cta" class="scroll-indicator" aria-label="Rolar para a próxima seção"></a>
  </section>

  <section id="clientes-e-depoimentos" class="clients-and-testimonials">
    
  <div class="container">
    <div class="clients-block">
      <h2>Nossos Clientes</h2>
      <p class="section-intro">Empresas que confiam em nossa experiência e qualidade</p>
      <div class="logos-grid">
        <?php
          $dir = __DIR__ . '/../assets/img/logoclientes/';
          $base = BASE . '/assets/img/logoclientes/';
          $allowed = ['png','webp','jpg','jpeg','svg'];
          $files = [];
          if (is_dir($dir)) {
            foreach (scandir($dir) as $f) {
              if ($f === '.' || $f === '..') continue;
              $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
              if (in_array($ext, $allowed)) $files[] = $f;
            }
          }
          natsort($files); $files = array_values($files);
          foreach ($files as $f) {
            $alt = ucwords(trim(preg_replace('/[-_]+/',' ', pathinfo($f, PATHINFO_FILENAME))));
            echo '<div class="logo-item"><img src="'.$base.$f.'" alt="'.htmlspecialchars($alt, ENT_QUOTES).'"></div>';
          }
        ?>
      </div>
    </div>

    <div class="testimonials-block">
      <h2>O que nossos clientes dizem</h2>
      <div class="testimonial-carousel" data-speed="0.6">
        <div class="testimonial-track">
          <div class="testimonial-card">
          <p>"Ótima atendimento. Sabem o que fazem com produtos de primeira.."</p>
          <div class="testimonial-author">
            <img src="https://i.pravatar.cc/40?u=1" alt="Avatar do cliente">
            <span>Emanuel Oliveira</span>
          </div>
        </div>
        <div class="testimonial-card">
          <p>"Qualidade no atendimento e pessoal bem treinado para atividades na área de pneumática !!."</p>
          <div class="testimonial-author">
            <img src="https://i.pravatar.cc/40?u=2" alt="Avatar do cliente">
            <span>Marcos Pagine</span>
          </div>
        </div>
        <div class="testimonial-card">
          <p>"Profissionalismo e qualidade.."</p>
          <div class="testimonial-author">
            <img src="https://i.pravatar.cc/40?u=3" alt="Avatar do cliente">
            <span>Edson Carlos</span>
          </div>
        </div>
        <div class="testimonial-card">
          <p>"Atendimento de qualidade."</p>
          <div class="testimonial-author">
            <img src="https://i.pravatar.cc/40?u=4" alt="Avatar do cliente">
            <span>Ezequiel Schlichting</span>
          </div>
        </div>
        <div class="testimonial-card">
          <p>"Muito Bom."</p>
          <div class="testimonial-author">
            <img src="https://i.pravatar.cc/40?u=5" alt="Avatar do cliente">
            <span>Rafael Herbert Bubl</span>
          </div>
        </div>
        <div class="testimonial-card">
          <p>"Donec sodales, augue ac tincidunt tincidunt, elit magna consequat enim, sit amet maximus tellus quam id elit."</p>
          <div class="testimonial-author">
            <img src="https://i.pravatar.cc/40?u=6" alt="Avatar do cliente">
            <span>Nome do Cliente 6, Empresa 6</span>
          </div>
        </div>
        <div class="testimonial-card">
          <p>"Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh."</p>
          <div class="testimonial-author">
            <img src="https://i.pravatar.cc/40?u=7" alt="Avatar do cliente">
            <span>Nome do Cliente 7, Empresa 7</span>
          </div>
        </div>
        <div class="testimonial-card">
          <p>"Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus."</p>
          <div class="testimonial-author">
            <img src="https://i.pravatar.cc/40?u=8" alt="Avatar do cliente">
            <span>Nome do Cliente 8, Empresa 8</span>
          </div>
        </div>
        <div class="testimonial-card">
          <p>"Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus."</p>
          <div class="testimonial-author">
            <img src="https://i.pravatar.cc/40?u=9" alt="Avatar do cliente">
            <span>Nome do Cliente 9, Empresa 9</span>
          </div>
        </div>
        <div class="testimonial-card">
          <p>"Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt."</p>
          <div class="testimonial-author">
            <img src="https://i.pravatar.cc/40?u=10" alt="Avatar do cliente">
            <span>Nome do Cliente 10, Empresa 10</span>
          </div>
        </div>
        </div>
      </div>
    </div>
  </div>
</section>

  <section id="cta">
    <canvas class="bg-canvas-right" id="cta-canvas" data-canvas="cta" data-effect="tris-left" data-density="1" aria-hidden="true"></canvas>
    <div class="container">
        <div class="cta-banner">
            <div class="cta-image">
                <img src="<?= BASE ?>/assets/img/especialista-cta.webp" alt="Especialista Arcompi">
            </div>
            <div class="cta-content">
                <h2>Pronto para aumentar a eficiência?</h2>
                <p>Fale com nossos especialistas e receba uma proposta sob medida.</p>
                <a class="btn btn-primary" href="<?= BASE ?>/contato">Falar com especialista</a>
            </div>
        </div>
    </div>
  </section>

</main>
<?php require __DIR__.'/../partials/footer.php'; ?>