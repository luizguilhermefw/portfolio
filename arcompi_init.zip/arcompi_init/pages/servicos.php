<?php require __DIR__.'/../partials/head.php'; ?>
<?php require __DIR__.'/../partials/header.php'; ?>

<main class="page-servicos">
  <section class="servicos-hero">
    <div class="container">
      <h1 class="servicos-hero-title">Soluções Completas em Ar Comprimido</h1>
      <p class="servicos-hero-subtitle">Do planejamento à manutenção, oferecemos um portfólio de serviços completo para garantir a máxima eficiência e confiabilidade do seu sistema de ar comprimido.</p>
    </div>
  </section>

  <section class="featured-services">
    <div class="container">

      <div class="service-row">
        <div class="service-image">
          <img src="<?= BASE ?>/assets/img/imghead/auditoria.webp" alt="Auditoria Móvel de Ar Comprimido" loading="lazy">
        </div>
        <div class="service-content">
          <span class="service-tag">Diagnóstico e Otimização</span>
          <h3>Auditoria Móvel</h3>
          <p>Diagnóstico completo do seu sistema para identificar vazamentos, analisar a qualidade do ar e medir o consumo de energia.</p>
          <a href="<?= BASE ?>/auditoria" class="btn btn-primary">Ver Detalhes</a>
        </div>
      </div>

      <div class="service-row">
        <div class="service-image">
          <img src="<?= BASE ?>/assets/img/imghead/arcompimanutencao.webp" alt="Assistência Técnica e Manutenção" loading="lazy">
        </div>
        <div class="service-content">
          <span class="service-tag">Suporte Especializado</span>
          <h3>Assistência Técnica</h3>
          <p>Manutenções preventivas, preditivas e corretivas com peças originais para garantir a máxima disponibilidade dos seus equipamentos.</p>
          <a href="<?= BASE ?>/contato" class="btn btn-primary">Solicitar Manutenção</a>
        </div>
      </div>

      <div class="service-row">
        <div class="service-image">
          <img src="<?= BASE ?>/assets/img/imghead/arcompifrente.webp" alt="Venda e Locação de Compressores" loading="lazy">
        </div>
        <div class="service-content">
          <span class="service-tag">Flexibilidade para seu Negócio</span>
          <h3>Venda e Locação</h3>
          <p>Portfólio completo de compressores, secadores e equipamentos, além de planos de locação flexíveis para necessidades pontuais.</p>
          <a href="<?= BASE ?>/contato" class="btn btn-primary">Consultar Equipamentos</a>
        </div>
      </div>

      <div class="service-row">
        <div class="service-image">
          <img src="<?= BASE ?>/assets/img/imghead/arcompiatendimento.webp" alt="Consultoria Especializada" loading="lazy">
        </div>
        <div class="service-content">
          <span class="service-tag">Inteligência e Estratégia</span>
          <h3>Consultoria Especializada</h3>
          <p>Análise de projetos e sistemas para propor soluções personalizadas, visando eficiência energética e menor custo operacional.</p>
          <a href="<?= BASE ?>/contato" class="btn btn-primary">Falar com um Consultor</a>
        </div>
      </div>

      <div class="service-row">
        <div class="service-image">
          <img src="<?= BASE ?>/assets/img/imghead/arcompi.jpeg" alt="Planos de Serviço" loading="lazy">
        </div>
        <div class="service-content">
          <span class="service-tag">Tranquilidade e Previsibilidade</span>
          <h3>Planos de Serviço</h3>
          <p>Contratos de manutenção programada com visitas técnicas, análise preditiva e serviços de emergência para sua tranquilidade.</p>
          <a href="<?= BASE ?>/contato" class="btn btn-primary">Conhecer Planos</a>
        </div>
      </div>

    </div>
  </section>

</main>

<?php require __DIR__.'/../partials/footer.php'; ?>