<?php require __DIR__.'/../partials/head.php'; ?>
<?php require __DIR__.'/../partials/header.php'; ?>
<main>
  <section>
    <div class="container">
      <h1>Contato</h1>
  <p class="contato-subtexto">Entre em contato com nossa equipe e descubra como podemos ajudar você a alcançar seus objetivos. Estamos prontos para tirar dúvidas, oferecer soluções personalizadas e garantir o melhor atendimento. Utilize o formulário ou escolha o canal de comunicação que preferir – responderemos o mais rápido possível.</p>
      <div class="contato-flex">
        <form class="contact-form" action="<?= BASE ?>/mail/send.php" method="post" novalidate>
          <input type="hidden" name="csrf" value="<?php echo htmlspecialchars($_SESSION['csrf'] ?? ''); ?>" />
          <div class="grid-2">
            <label>Nome*
              <input type="text" name="nome" required />
            </label>
            <label>E-mail*
              <input type="email" name="email" required />
            </label>
          </div>
          <label>Telefone
            <input type="text" name="telefone" />
          </label>
          <label>Assunto*
            <input type="text" name="assunto" required />
          </label>
          <label>Mensagem*
            <textarea name="mensagem" rows="5" required></textarea>
          </label>
          <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" />
          <button class="btn btn-primary" type="submit">Enviar mensagem</button>
        </form>
        <aside class="contato-info">
          <img src="<?= BASE ?>/assets/img/arcompi-fachada.webp" alt="Fachada Arcompi" class="contato-fachada" width="100%" style="max-width: 100%; border-radius: 10px; margin-bottom: 18px; box-shadow: 0 2px 12px rgba(16,108,180,0.10);" loading="lazy" />
          <h2>Informações de Contato</h2>
          <p><strong>Endereço:</strong><br>
          R. Pio XII, 705<br>
          Neva, Cascavel - PR<br>
          85802-170
          </p>
          <p><strong>Telefone:</strong><br>
            <a href="tel:+554533062850">(45) 3306-2850</a>
          </p>
          <p><strong>E-mail:</strong><br>
            <a href="mailto:contato@arcompi.com.br">contato@arcompi.com.br</a>
          </p>
          <div class="contato-mapa">
          <iframe src="https://www.google.com/maps?q=R.+Pio+XII,+705+-+Neva,+Cascavel+-+PR,+85802-170&z=16&output=embed" width="100%" height="180" style="border:0; border-radius:10px;" allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
          </div>
        </aside>
      </div>
    </div>
  </section>
</main>
<?php require __DIR__.'/../partials/footer.php'; ?>