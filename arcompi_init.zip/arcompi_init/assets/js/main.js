(function(){
  const hamb = document.querySelector('.hamb');
  const nav = document.getElementById('nav');
  if(hamb && nav){
    hamb.addEventListener('click',()=>{
      const open = nav.classList.toggle('open');
      hamb.setAttribute('aria-expanded', open? 'true':'false');
    });
    // Auto-fecha o menu ao clicar em um link
    nav.addEventListener('click', (e)=>{
      const t = e.target;
      if(t && t.tagName === 'A' && nav.classList.contains('open')){
        nav.classList.remove('open');
        hamb.setAttribute('aria-expanded','false');
      }
    });
  }

  // Submenu (Serviços)
  (function(){
    const parent = document.querySelector('.menu-item.has-submenu');
    if(!parent) return;
  const btn = parent.querySelector('.submenu-toggle');
    const submenu = parent.querySelector('.submenu');
    if(!btn || !submenu) return;
    // Toggle em click (suporte a mobile)
    btn.addEventListener('click', (e)=>{
      // Se o submenu já está aberto e o usuário clicar novamente, navega normalmente
      const alreadyOpen = parent.classList.contains('open');
      // Em telas desktop, preferimos abrir ao invés de navegar no primeiro clique
      if(!alreadyOpen){ e.preventDefault(); }
      const open = parent.classList.toggle('open');
      btn.setAttribute('aria-expanded', open? 'true':'false');
    });
    // Fecha ao clicar fora (desktop)
    document.addEventListener('click', (e)=>{
      if(!parent.classList.contains('open')) return;
      const t = e.target;
      if(t!==btn && !parent.contains(t)){
        parent.classList.remove('open');
        btn.setAttribute('aria-expanded','false');
      }
    });
  })();

  // Canvas estático geométrico (suporta múltiplos e qualquer seção com data-canvas)
  (function(){
  const canvases = document.querySelectorAll('canvas[data-canvas], #services-canvas, #services-canvas-bg');
    if(!canvases.length) return;
    function initOne(canvas){
      const ctx = canvas.getContext('2d');
    const dpr = Math.max(1, Math.min(2, window.devicePixelRatio||1));
    const styles = getComputedStyle(document.documentElement);
    const brand = (styles.getPropertyValue('--brand-primary')||'#106CB4').trim();
    const dark = (styles.getPropertyValue('--brand-dark')||'#0A2540').trim();
    const effect = (canvas.getAttribute('data-effect')||'tris').toLowerCase();
    const density = parseFloat(canvas.getAttribute('data-density')||'1');
    function hex2rgb(h){
      h = h.trim(); if(h[0]==='#') h = h.slice(1);
      if(h.length===3) h = h.split('').map(x=>x+x).join('');
      const n = parseInt(h,16); return {r:(n>>16)&255,g:(n>>8)&255,b:n&255};
    }
    function rgba(hex,a){ const {r,g,b}=hex2rgb(hex); return `rgba(${r},${g},${b},${a})`; }
    let width=0,height=0;
    function resize(){
      const rect = canvas.getBoundingClientRect();
      width = Math.max(200, Math.floor(rect.width));
      height = Math.max(200, Math.floor(rect.height));
      canvas.width = Math.floor(width*dpr);
      canvas.height = Math.floor(height*dpr);
      ctx.setTransform(dpr,0,0,dpr,0,0);
      draw();
    }
    function poly(points, fill){
      ctx.beginPath();
      points.forEach((p,i)=> i? ctx.lineTo(p[0],p[1]) : ctx.moveTo(p[0],p[1]));
      ctx.closePath(); ctx.fillStyle = fill; ctx.fill();
    }
    // Efeito 1: triângulos sobrepostos (tris)
    function drawTris(){
      ctx.clearRect(0,0,width,height);
      const b1 = rgba(brand, 0.22);
      const b2 = rgba(brand, 0.12);
      const d1 = rgba(dark, 0.18);
      const d2 = rgba(dark, 0.10);
      const w = width, h = height;
      poly([[w*0.08,h*0.10],[w*1.00,h*0.18],[w*1.00,h*0.85]], b1);
      poly([[w*0.00,h*0.55],[w*0.62,h*0.38],[w*0.62,h*1.00]], d1);
      poly([[w*0.20,h*0.00],[w*1.00,h*0.00],[w*1.00,h*0.40]], b2);
      poly([[w*0.10,h*0.70],[w*0.85,h*0.55],[w*0.85,h*1.00]], d2);
      ctx.strokeStyle = rgba(brand, 0.25); ctx.lineWidth = 1.2;
      for(let y=h*0.2; y<h; y+=h*0.18){ ctx.beginPath(); ctx.moveTo(w*0.1,y); ctx.lineTo(w,y-h*0.08); ctx.stroke(); }
    }
    // Variante: triângulos do lado direito apontando para a esquerda (em direção ao conteúdo)
    function drawTrisLeft(){
      ctx.clearRect(0,0,width,height);
      const b1 = rgba(brand, 0.22);
      const b2 = rgba(brand, 0.12);
      const d1 = rgba(dark, 0.18);
      const d2 = rgba(dark, 0.10);
      const w = width, h = height;
      // Triângulos ancorados na direita, pontas em direção ao centro
      poly([[w*1.00,h*0.12],[w*0.66,h*0.28],[w*1.00,h*0.58]], b1);
      poly([[w*1.00,h*0.46],[w*0.58,h*0.56],[w*1.00,h*0.92]], d1);
      poly([[w*1.00,h*0.00],[w*0.72,h*0.00],[w*1.00,h*0.30]], b2);
      poly([[w*1.00,h*0.78],[w*0.70,h*0.92],[w*1.00,h*1.00]], d2);
      // linhas convergentes para reforçar direção ao conteúdo
      ctx.strokeStyle = rgba(brand, 0.22); ctx.lineWidth = 1.1;
      for(let i=0;i<6;i++){
        const ty = h*(0.15 + i*0.14);
        ctx.beginPath(); ctx.moveTo(w, ty); ctx.lineTo(w*0.62, h*0.5 + (i-2.5)*h*0.06); ctx.stroke();
      }
    }
    // Variante: triângulos do lado esquerdo apontando para a direita (em direção ao conteúdo)
    function drawTrisRight(){
      ctx.clearRect(0,0,width,height);
      const b1 = rgba(brand, 0.22);
      const b2 = rgba(brand, 0.12);
      const d1 = rgba(dark, 0.18);
      const d2 = rgba(dark, 0.10);
      const w = width, h = height;
      // Triângulos ancorados na esquerda, pontas em direção ao centro
      poly([[w*0.00,h*0.12],[w*0.34,h*0.28],[w*0.00,h*0.58]], b1);
      poly([[w*0.00,h*0.46],[w*0.42,h*0.56],[w*0.00,h*0.92]], d1);
      poly([[w*0.00,h*0.00],[w*0.28,h*0.00],[w*0.00,h*0.30]], b2);
      poly([[w*0.00,h*0.78],[w*0.30,h*0.92],[w*0.00,h*1.00]], d2);
      // linhas convergentes para reforçar direção ao conteúdo
      ctx.strokeStyle = rgba(brand, 0.22); ctx.lineWidth = 1.1;
      for(let i=0;i<6;i++){
        const ty = h*(0.15 + i*0.14);
        ctx.beginPath(); ctx.moveTo(0, ty); ctx.lineTo(w*0.38, h*0.5 + (i-2.5)*h*0.06); ctx.stroke();
      }
    }
    // Efeito 2: grade hexagonal (hex)
    function drawHex(){
      ctx.clearRect(0,0,width,height);
      const r = Math.max(10, Math.min(36, 26/density)); // raio da célula
      const hexH = Math.sqrt(3)*r; // altura do hex
      const stepX = 1.5*r; // distância entre centros nas colunas
      const stepY = hexH;   // distância entre centros nas linhas
      const strokeA = 0.18, strokeB = 0.10;
      ctx.lineWidth = 1;
      const w = width, h = height;
      function drawHexAt(cx, cy, color){
        ctx.beginPath();
        for(let i=0;i<6;i++){
          const ang = Math.PI/3*i + Math.PI/6; // flat-top
          const x = cx + r*Math.cos(ang);
          const y = cy + r*Math.sin(ang);
          if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
        }
        ctx.closePath();
        ctx.strokeStyle = color; ctx.stroke();
      }
      for(let row= -1, y=0; y< h + hexH; row++, y += stepY){
        const offset = (row%2===0) ? 0 : stepX/2;
        for(let x=-r; x< w + r; x += stepX){
          const c1 = rgba(brand, strokeA);
          const c2 = rgba(dark, strokeB);
          drawHexAt(x + offset, y, (row + Math.floor(x/stepX)) % 2 === 0 ? c1 : c2);
        }
      }
    }
    // Efeito 3: grade isométrica (iso)
    function drawIso(){
      ctx.clearRect(0,0,width,height);
      const step = Math.max(12, Math.min(36, 24/density));
      const w = width, h = height;
      ctx.lineWidth = 1;
      const c1 = rgba(brand, 0.18), c2 = rgba(dark, 0.12), c3 = rgba('#ffffff', 0.06);
      // Conjunto 1: linhas inclinadas 60° (subindo)
      ctx.strokeStyle = c1;
      for(let x=-h; x<w+ h; x+=step){
        ctx.beginPath(); ctx.moveTo(x, h); ctx.lineTo(x+h, 0); ctx.stroke();
      }
      // Conjunto 2: linhas inclinadas -60° (descendo)
      ctx.strokeStyle = c2;
      for(let x=0; x<w+ h; x+=step){
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x-h, h); ctx.stroke();
      }
      // Conjunto 3: leves linhas verticais para reforçar o iso
      ctx.strokeStyle = c3;
      for(let x=0; x<w; x+=step){ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke(); }
    }
    function draw(){
      switch(effect){
        case 'hex': return drawHex();
        case 'iso': return drawIso();
        case 'tris-left': return drawTrisLeft();
  case 'tris-right': return drawTrisRight();
        case 'tris':
        default: return drawTris();
      }
    }
      window.addEventListener('resize', resize, {passive:true});
      // atraso para garantir layout aplicado
      setTimeout(resize, 0);
    }
    canvases.forEach(initOne);
  })();
  // Sticky header: adiciona sombra ao rolar
  const header = document.querySelector('.site-header');
  const onScroll = ()=>{ if(header){ header.classList.toggle('scrolled', window.scrollY > 4); } };
  window.addEventListener('scroll', onScroll, {passive:true});
  onScroll();

  // Parallax sutil no herói
  (function(){
    const media = document.querySelector('.hero-media');
    if(!media) return;
    let ticking = false;
    function raf(){
      const y = window.scrollY || 0; // movimento reduzido
      const t = Math.max(0, Math.min(1, y/500));
      media.style.transform = `translateY(${t*10}px)`;
      ticking = false;
    }
    function on(){ if(!ticking){ window.requestAnimationFrame(raf); ticking=true; } }
    window.addEventListener('scroll', on, {passive:true});
    raf();
  })();

  // Canvas de fundo no herói: efeitos 'airflow' (padrão), 'streaks', 'drift' (lento), 'stream' (linhas curvas), 'vortex' (redemoinho), 'wind3d' (vento pseudo-3D), 'ribbons3d' (fitas 3D), 'pipes' (rede de tubulações), 'jet' (jato/streamlines) ou 'leaves' (folhas soprando lentamente)
  (function(){
    const canvas = document.getElementById('hero-canvas');
    if(!canvas) return;
  const effect = (canvas.getAttribute('data-effect')||'airflow').toLowerCase();
    const ctx = canvas.getContext('2d');
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    let dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
    let width = 0, height = 0, running = false, rafId;
    const styles = getComputedStyle(document.documentElement);
  const brand = (styles.getPropertyValue('--brand-primary')||'#106CB4').trim();
  const dark = (styles.getPropertyValue('--brand-dark')||'#0A2540').trim();

    function toRGBA(c,a){
      c = c.trim();
      if(c.startsWith('rgba')) return c.replace(/rgba\(([^)]+)\)/, (m,p)=>`rgba(${p.split(',').slice(0,3).join(',')}, ${a})`);
      if(c.startsWith('rgb')) return c.replace(/rgb\(([^)]+)\)/, (m,p)=>`rgba(${p}, ${a})`);
      if(c.startsWith('#')){
        let r=0,g=0,b=0; if(c.length===4){ r=parseInt(c[1]+c[1],16); g=parseInt(c[2]+c[2],16); b=parseInt(c[3]+c[3],16); }
        else { r=parseInt(c.slice(1,3),16); g=parseInt(c.slice(3,5),16); b=parseInt(c.slice(5,7),16); }
        return `rgba(${r}, ${g}, ${b}, ${a})`;
      }
      return `rgba(16,108,180, ${a})`;
    }

    // ===== airflow =====
    const lines = [];
    function resetLines(){
      lines.length = 0;
      const count = Math.max(6, Math.min(12, Math.floor(height/110)));
      for(let i=0;i<count;i++){
        const y = (height*0.18) + (i/(count-1||1))*(height*0.64);
        lines.push({
          baseY: y + (i%2? 8:-8), amp: 8 + Math.random()*18,
          freq: 0.006 + Math.random()*0.008, phase: Math.random()*Math.PI*2,
          speed: 0.004 + Math.random()*0.006, lw: (i%3===0? 1.6 : 1.1),
          color: i%2 ? toRGBA(brand, 0.28) : toRGBA(dark, 0.18),
          particle: { t: Math.random(), r: 1.8 + Math.random()*1.4, a: 0.55 }
        });
      }
    }
    function drawAirflow(){
      ctx.clearRect(0,0,width,height);
      const g = ctx.createLinearGradient(0,0,width,0);
      g.addColorStop(0, toRGBA(brand, 0.08)); g.addColorStop(1, toRGBA(dark, 0.06));
      ctx.fillStyle = g; ctx.fillRect(0,0,width,height);
      const step = 24;
      for(const L of lines){
        L.phase += L.speed;
        ctx.beginPath();
        for(let x=0; x<=width+step; x+=step){
          const y = L.baseY + Math.sin(x*L.freq + L.phase) * L.amp;
          if(x===0) ctx.moveTo(0, y); else ctx.lineTo(x, y);
        }
        ctx.strokeStyle = L.color; ctx.lineWidth = L.lw; ctx.lineCap = 'round'; ctx.stroke();
        L.particle.t += L.speed * 0.35; if(L.particle.t>1) L.particle.t = 0;
        const px = L.particle.t * width; const py = L.baseY + Math.sin(px*L.freq + L.phase) * L.amp;
        ctx.beginPath(); ctx.fillStyle = toRGBA('#ffffff', L.particle.a); ctx.arc(px, py, L.particle.r, 0, Math.PI*2); ctx.fill();
      }
    }

    // ===== streaks =====
    const streaks = [];
    function resetStreaks(){
      streaks.length = 0;
      const rows = Math.max(6, Math.min(14, Math.floor(height/80)));
      for(let i=0;i<rows;i++){
        const baseY = height*0.15 + (i/(rows-1||1))*(height*0.7);
        const count = Math.max(6, Math.floor(width/220));
        for(let j=0;j<count;j++){
          const len = 30 + Math.random()*80;
          streaks.push({
            x: Math.random()*width, baseY,
            amp: 6 + Math.random()*18, freq: 0.004 + Math.random()*0.01, phase: Math.random()*Math.PI*2,
            speed: 0.6 + Math.random()*1.2, len, lw: (i%3===0? 1.4:1.1),
            color: i%2 ? toRGBA(brand, 0.22) : toRGBA('#ffffff', 0.12)
          });
        }
      }
    }
    function drawStreaks(){
      // véu com leve persistência para rastro
      ctx.fillStyle = toRGBA(dark, 0.05); ctx.fillRect(0,0,width,height);
      for(const s of streaks){
        s.x += s.speed; if(s.x - s.len > width) s.x = -10;
        const y = s.baseY + Math.sin(s.x*s.freq + s.phase)*s.amp;
        ctx.beginPath(); ctx.strokeStyle = s.color; ctx.lineWidth = s.lw; ctx.lineCap='round';
        ctx.moveTo(s.x - s.len, y - 0.6); ctx.lineTo(s.x, y + 0.6); ctx.stroke();
      }
    }

  // ===== drift (vento lento em campo fluido) =====
    const particles = [];
    let time = 0;
    const speedAttr = parseFloat(canvas.getAttribute('data-speed')||'1');
    const driftSpeed = isNaN(speedAttr) ? 1 : Math.max(0.2, Math.min(2, speedAttr));
    function resetDrift(){
      particles.length = 0;
      const count = Math.max(28, Math.min(80, Math.floor((width*height)/28000)));
      for(let i=0;i<count;i++){
        particles.push({
          x: Math.random()*width,
          y: height*(0.12 + Math.random()*0.76),
          r: 1 + Math.random()*1.2,
          a: 0.22 + Math.random()*0.18,
          tint: (i%3===0) ? toRGBA('#ffffff', 0.14 + Math.random()*0.12) : toRGBA(brand, 0.20 + Math.random()*0.16)
        });
      }
      time = 0;
    }
    function drawDrift(){
      // véu leve e persistente para rastro
      ctx.fillStyle = toRGBA(dark, 0.04);
      ctx.fillRect(0,0,width,height);
      time += 0.003 * driftSpeed; // lento por padrão
      for(const p of particles){
        const nx = (p.x/width), ny = (p.y/height);
        const angle = Math.sin(ny*2.2 + time)*0.9 + Math.cos(nx*1.3 + time*0.6)*0.7;
        const vx = 0.25 + Math.cos(angle)*0.18;
        const vy = Math.sin(angle)*0.18;
        const s = 0.65 * driftSpeed; // escala de velocidade geral (lento)
        const ox = p.x, oy = p.y;
        p.x += vx*s; p.y += vy*s;
        // wrap
        if(p.x < -5) p.x = width+5; else if(p.x>width+5) p.x = -5;
        if(p.y < height*0.08) p.y = height*0.92; else if(p.y>height*0.92) p.y = height*0.08;
        // render como pequeno traço do ponto antigo ao novo
        ctx.beginPath();
        ctx.strokeStyle = p.tint;
        ctx.lineWidth = p.r;
        ctx.moveTo(ox, oy);
        ctx.lineTo(p.x, p.y);
        ctx.stroke();
      }
    }

    // ===== stream (linhas curvas em fluxo lento) =====
    const streams = [];
    let tstream = 0;
    function resetStream(){
      streams.length = 0;
      const count = Math.max(36, Math.min(120, Math.floor((width*height)/25000)));
      for(let i=0;i<count;i++){
        streams.push({
          x: Math.random()*width,
          y: height*(0.16 + Math.random()*0.68),
          speed: (0.35 + Math.random()*0.35),
          lw: (Math.random()<0.25 ? 1.6 : 1.1),
          alpha: 0.16 + Math.random()*0.2,
          hueAlt: Math.random()<0.2
        });
      }
      tstream = 0;
    }
    function drawStream(){
      // véu com leve persistência para rastro
      ctx.fillStyle = toRGBA(dark, 0.045);
      ctx.fillRect(0,0,width,height);
      tstream += 0.0025 * driftSpeed; // lento por padrão
      for(const s of streams){
        const ox = s.x, oy = s.y;
        // campo vetorial suave dependente do tempo
        const nx = s.x/width, ny = s.y/height;
        const ang = Math.sin(nx*3.4 - tstream*0.6)*1.1 + Math.cos(ny*2.6 + tstream*0.9)*0.9;
        const vx = Math.cos(ang) * s.speed * 0.9;
        const vy = Math.sin(ang) * s.speed * 0.6;
        s.x += vx * driftSpeed; s.y += vy * driftSpeed;
        // wrap
        if(s.x < -8) s.x = width+8; else if(s.x>width+8) s.x = -8;
        if(s.y < height*0.10) s.y = height*0.90; else if(s.y>height*0.90) s.y = height*0.10;
        // curva: controla ponto no futuro para suavizar
        const mx = s.x + vx*10;
        const my = s.y + vy*10;
        ctx.beginPath();
        ctx.lineWidth = s.lw * (0.85 + 0.15*Math.sin(tstream*2 + nx*4));
        const col = s.hueAlt ? toRGBA('#ffffff', s.alpha*0.8) : toRGBA(brand, s.alpha*1.1);
        ctx.strokeStyle = col;
        ctx.lineCap = 'round';
        ctx.moveTo(ox, oy);
        ctx.quadraticCurveTo(mx, my, s.x, s.y);
        ctx.stroke();
      }
    }

    function resize(){
      const rect = canvas.getBoundingClientRect();
      width = Math.floor(rect.width); height = Math.floor(rect.height);
      canvas.width = Math.floor(width * dpr); canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr,0,0,dpr,0,0);
  if(effect==='streaks'){ resetStreaks(); }
  else if(effect==='drift'){ resetDrift(); }
  else if(effect==='stream'){ resetStream(); }
  else if(effect==='vortex'){ resetVortex(); }
  else if(effect==='wind3d'){ resetWind3D(); }
  else if(effect==='ribbons3d'){ resetRibbons3D(); }
  else if(effect==='pipes'){ resetPipes(); }
  else if(effect==='jet'){ resetJet(); }
  else if(effect==='leaves'){ resetLeaves(); }
      else { resetLines(); }
      // limpa para primeiro frame
      ctx.clearRect(0,0,width,height);
    }

    function loop(){
      if(!running) return;
  if(effect==='streaks') drawStreaks();
  else if(effect==='drift') drawDrift();
  else if(effect==='stream') drawStream();
  else if(effect==='vortex') drawVortex();
  else if(effect==='wind3d') drawWind3D();
  else if(effect==='ribbons3d') drawRibbons3D();
  else if(effect==='pipes') drawPipes();
  else if(effect==='jet') drawJet();
  else if(effect==='leaves') drawLeaves();
      else drawAirflow();
      rafId = requestAnimationFrame(loop);
    }

    // ===== vortex (redemoinho de vento) =====
    const vort = { cx: 0, cy: 0, k: 28 };
    const vortParticles = [];
    function resetVortex(){
      const vxAttr = parseFloat(canvas.getAttribute('data-vx')||'0.62');
      const vyAttr = parseFloat(canvas.getAttribute('data-vy')||'0.48');
      const vx = isNaN(vxAttr)? 0.62 : Math.min(0.95, Math.max(0.05, vxAttr));
      const vy = isNaN(vyAttr)? 0.48 : Math.min(0.90, Math.max(0.10, vyAttr));
      vort.cx = width * vx; vort.cy = height * vy;
      vort.k = 22 + Math.min(width,height)*0.02; // intensidade proporcional ao tamanho
      vortParticles.length = 0;
      const count = Math.max(40, Math.min(120, Math.floor((width*height)/22000)));
      for(let i=0;i<count;i++){
        const angle = Math.random()*Math.PI*2;
        const radius = Math.min(width,height)*(0.12 + Math.random()*0.45);
        vortParticles.push({
          x: vort.cx + Math.cos(angle)*radius,
          y: vort.cy + Math.sin(angle)*radius,
          w: 0.6 + Math.random()*0.9,
          a: 0.14 + Math.random()*0.18,
          tint: (i%4===0) ? toRGBA('#ffffff', 0.16 + Math.random()*0.12) : toRGBA(brand, 0.18 + Math.random()*0.14),
          jitter: (Math.random()*0.6+0.4) * (Math.random()<0.5?-1:1)
        });
      }
    }
    function drawVortex(){
      // véu com leve persistência para caminho
      ctx.fillStyle = toRGBA(dark, 0.045);
      ctx.fillRect(0,0,width,height);
      const base = (parseFloat(canvas.getAttribute('data-speed')||'1')); // 1 = padrão
      const speedFactor = (isNaN(base)?1:base);
      for(const p of vortParticles){
        const ox = p.x, oy = p.y;
        let dx = p.x - vort.cx; let dy = p.y - vort.cy;
        const r2 = dx*dx + dy*dy + 0.0001;
        const r = Math.sqrt(r2);
        // componente tangencial (90° rotacionada) + leve radial para não travar
        const tscale = vort.k / (50 + r); // mais lento quanto mais longe
        let tx = -dy * tscale;
        let ty =  dx * tscale;
        // leve atração/repulsão para formar o olho
        const rscale = (r>Math.min(width,height)*0.22 ? -0.002 : 0.004);
        let rx = dx * rscale;
        let ry = dy * rscale;
        // jitter suave para naturalidade
        const jx = Math.sin(oy*0.02 + p.jitter) * 0.12;
        const jy = Math.cos(ox*0.015 - p.jitter) * 0.10;
        const s = 0.6 * speedFactor; // controle geral de velocidade (discreto)
        p.x += (tx + rx + jx) * s;
        p.y += (ty + ry + jy) * s;
        // wrap suave nas bordas
        if(p.x < -8) p.x = width+8; else if(p.x>width+8) p.x = -8;
        if(p.y < -8) p.y = height+8; else if(p.y>height+8) p.y = -8;
        // desenha o traço
        ctx.beginPath();
        ctx.strokeStyle = p.tint;
        ctx.lineWidth = p.w;
        ctx.lineCap = 'round';
        ctx.moveTo(ox, oy);
        ctx.lineTo(p.x, p.y);
        ctx.stroke();
      }
      // sutil indicação do olho (quase invisível)
      const eyeR = Math.min(width,height)*0.05;
      const grd = ctx.createRadialGradient(vort.cx, vort.cy, 0, vort.cx, vort.cy, eyeR);
      grd.addColorStop(0, toRGBA('#ffffff', 0.06));
      grd.addColorStop(1, toRGBA('#ffffff', 0.0));
      ctx.fillStyle = grd;
      ctx.beginPath(); ctx.arc(vort.cx, vort.cy, eyeR, 0, Math.PI*2); ctx.fill();
    }

    // ===== wind3d (vento em pseudo-3D com projeção em perspectiva) =====
    const w3d = { cx: 0, cy: 0, fov: 450, near: 50, far: 900 };
    const wind = [];
    let tw3d = 0;
    function resetWind3D(){
      w3d.cx = width*0.5; w3d.cy = height*0.5;
      // ajusta profundidade conforme altura da tela
      w3d.fov = Math.max(280, Math.min(800, Math.floor(Math.min(width,height)*1.2)));
      w3d.near = 40; w3d.far = Math.max(600, Math.floor(Math.min(width,height)*1.8));
      const densAttr = parseFloat(canvas.getAttribute('data-density')||'1');
      const density = isNaN(densAttr)? 1 : Math.max(0.4, Math.min(1.8, densAttr));
      const count = Math.max(80, Math.min(260, Math.floor((width*height)/12000 * density)));
      wind.length = 0;
      for(let i=0;i<count;i++){
        // espaço em torno da câmera
        const z = Math.random()*(w3d.far - w3d.near) + w3d.near;
        wind.push({
          x: (Math.random()-0.5)*width*1.8,
          y: (Math.random()-0.5)*height*1.8,
          z,
          px: 0, py: 0, // projecções anteriores
          w: 0.8 + Math.random()*1.2,
          hueAlt: Math.random() < 0.25,
          a: 0.12 + Math.random()*0.18
        });
      }
      tw3d = 0;
      // limpeza inicial
      ctx.clearRect(0,0,width,height);
    }
    function drawWind3D(){
      // leve persistência para rastro
      ctx.fillStyle = toRGBA(dark, 0.05);
      ctx.fillRect(0,0,width,height);
      const base = parseFloat(canvas.getAttribute('data-speed')||'0.8');
      const speed = (isNaN(base)?0.8:base);
      tw3d += 0.002*speed;
      for(const p of wind){
        // atualizar posição em z (vindo na direção da câmera) e drift lateral
        const driftX = Math.sin((p.y*0.002) + tw3d*2.1) * 0.4;
        const driftY = Math.cos((p.x*0.0016) + tw3d*1.7) * 0.35;
        p.x += driftX * speed; p.y += driftY * speed;
        p.z -= 2.2 * speed; // aproxima
        if(p.z < w3d.near){
          p.z = w3d.far; // reaparece longe
          p.x = (Math.random()-0.5)*width*1.6;
          p.y = (Math.random()-0.5)*height*1.6;
          p.px = p.py = 0;
        }
        // projeção
        const scale = w3d.fov / p.z;
        const sx = w3d.cx + p.x * scale;
        const sy = w3d.cy + p.y * scale;
        // traço do ponto anterior -> atual (motion streak)
        if(p.px && p.py){
          ctx.beginPath();
          const col = p.hueAlt ? toRGBA('#ffffff', p.a*0.9) : toRGBA(brand, p.a*1.1);
          ctx.strokeStyle = col;
          ctx.lineWidth = Math.max(0.6, p.w * (1.2 - p.z/w3d.far));
          ctx.moveTo(p.px, p.py);
          ctx.lineTo(sx, sy);
          ctx.stroke();
        } else {
          // ponto inicial (sem rastro ainda)
          ctx.beginPath();
          ctx.fillStyle = toRGBA('#ffffff', 0.10);
          ctx.arc(sx, sy, 0.6, 0, Math.PI*2); ctx.fill();
        }
        p.px = sx; p.py = sy;
        // recicla se sair visível muito para fora (evita linhas longas cruzando a tela)
        if(sx < -50 || sx > width+50 || sy < -50 || sy > height+50){
          p.z = w3d.far; p.x = (Math.random()-0.5)*width*1.6; p.y = (Math.random()-0.5)*height*1.6;
          p.px = p.py = 0;
        }
      }
    }

    // ===== ribbons3d (fitas em perspectiva) =====
    const rb3d = { cx: 0, cy: 0, fov: 520, far: 1400 };
    const ribbons = [];
    function resetRibbons3D(){
      rb3d.cx = width*0.5; rb3d.cy = height*0.5;
      rb3d.fov = Math.max(320, Math.min(900, Math.floor(Math.min(width,height)*1.3)));
      rb3d.far = Math.max(800, Math.floor(Math.min(width,height)*2.2));
      ribbons.length = 0;
      const nAttr = parseInt(canvas.getAttribute('data-ribbons')||'3',10);
      const n = isNaN(nAttr)? 3 : Math.max(1, Math.min(6, nAttr));
      const segs = Math.max(40, Math.min(120, Math.floor(height*0.6)));
      for(let i=0;i<n;i++){
        const color = i%2 ? toRGBA(brand, 0.28) : toRGBA('#ffffff', 0.16);
        const widthBase = 4 + Math.random()*5;
        const freq = 0.0018 + Math.random()*0.0015;
        const amp = (height*0.08) + Math.random()*(height*0.12);
        const phase = Math.random()*Math.PI*2;
        const tilt = (Math.random()*0.8 - 0.4); // inclinação lateral
        const points = [];
        // distribui os pontos ao longo de z para dar profundidade
        for(let j=0;j<segs;j++){
          const t = j/segs;
          const z = (1-t)*rb3d.far; // mais longe no começo
          const x = (Math.random()-0.5)*width*0.2; // base lateral leve
          const y = (Math.random()-0.5)*height*0.15;
          points.push({x,y,z});
        }
        ribbons.push({color, widthBase, freq, amp, phase, tilt, points});
      }
      // limpar
      ctx.clearRect(0,0,width,height);
    }
    function drawRibbons3D(){
      // véu sutil de fundo
      ctx.fillStyle = toRGBA(dark, 0.045);
      ctx.fillRect(0,0,width,height);
      const base = parseFloat(canvas.getAttribute('data-speed')||'0.7');
      const speed = (isNaN(base)?0.7:base);
      for(const r of ribbons){
        // atualiza a animação dos pontos ao longo de z
        for(const p of r.points){
          p.z -= 2.0 * speed; // aproxima
          if(p.z < 60){ p.z = rb3d.far; p.x = (Math.random()-0.5)*width*0.2; p.y = (Math.random()-0.5)*height*0.15; }
        }
        // desenha a fita como polilinha grossa projetada
        ctx.beginPath();
        let first = true;
        let lwLast = r.widthBase;
        for(let idx=0; idx<r.points.length; idx++){
          const p = r.points[idx];
          // movimento senoidal ao longo do z + leve inclinação
          const sway = Math.sin(p.z*r.freq + r.phase) * r.amp;
          const x3 = p.x + sway + p.z*0.002*r.tilt*width*0.0015;
          const y3 = p.y + Math.cos(p.z*r.freq*0.8 + r.phase*0.7) * (r.amp*0.45);
          const scale = rb3d.fov / p.z;
          const sx = rb3d.cx + x3 * scale;
          const sy = rb3d.cy + y3 * scale;
          const lw = Math.max(1, r.widthBase * (1.2 - p.z/rb3d.far));
          if(first){ ctx.moveTo(sx, sy); first=false; }
          else { ctx.lineTo(sx, sy); }
          lwLast = lw;
        }
        ctx.strokeStyle = r.color;
        ctx.lineWidth = lwLast;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.stroke();
      }
    }

    // ===== pipes (rede de tubulações com pulsos de ar) =====
    const pipes = { rows: [], cols: [], nodes: [], packets: [] };
    function resetPipes(){
      pipes.rows = []; pipes.cols = []; pipes.nodes = []; pipes.packets = [];
      const marginX = Math.max(24, Math.floor(width*0.06));
      const marginY = Math.max(24, Math.floor(height*0.10));
      const yCount = Math.max(3, Math.min(8, Math.floor(height/140)));
      const xCount = Math.max(3, Math.min(7, Math.floor(width/220)));
      // posições de linhas horizontais
      for(let i=0;i<yCount;i++){
        const t = i/(yCount-1||1);
        const jitter = (Math.random()*0.05 - 0.025) * height;
        const y = marginY + t*(height - marginY*2) + jitter;
        pipes.rows.push(Math.max(marginY, Math.min(height-marginY, y)));
      }
      // posições de linhas verticais
      for(let j=0;j<xCount;j++){
        const t = j/(xCount-1||1);
        const jitter = (Math.random()*0.06 - 0.03) * width;
        const x = marginX + t*(width - marginX*2) + jitter;
        pipes.cols.push(Math.max(marginX, Math.min(width-marginX, x)));
      }
      // nós (interseções)
      for(const y of pipes.rows){ for(const x of pipes.cols){ pipes.nodes.push({x,y}); } }
      // pacotes (pulsos) ao longo das linhas
      const densAttr = parseFloat(canvas.getAttribute('data-density')||'1');
      const density = isNaN(densAttr)? 1 : Math.max(0.6, Math.min(2.0, densAttr));
      const baseCount = Math.floor((pipes.rows.length + pipes.cols.length) * 6 * density);
      for(let k=0;k<baseCount;k++){
        const vertical = Math.random()<0.45; // parte vai nas verticais
        if(vertical){
          const colIdx = Math.floor(Math.random()*pipes.cols.length);
          const x = pipes.cols[colIdx];
          pipes.packets.push({ axis:'v', idx: colIdx, t: Math.random(), dir: Math.random()<0.5?1:-1, sp: 0.003 + Math.random()*0.006 });
        } else {
          const rowIdx = Math.floor(Math.random()*pipes.rows.length);
          const y = pipes.rows[rowIdx];
          pipes.packets.push({ axis:'h', idx: rowIdx, t: Math.random(), dir: Math.random()<0.5?1:-1, sp: 0.003 + Math.random()*0.006 });
        }
      }
      // limpeza
      ctx.clearRect(0,0,width,height);
    }
    function drawPipes(){
      // fundo sutil
      ctx.fillStyle = toRGBA(dark, 0.05); ctx.fillRect(0,0,width,height);
      // desenha tubulações
      ctx.lineCap = 'round';
      for(const y of pipes.rows){
        ctx.beginPath(); ctx.strokeStyle = toRGBA(brand, 0.18); ctx.lineWidth = 3;
        ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
      }
      for(const x of pipes.cols){
        ctx.beginPath(); ctx.strokeStyle = toRGBA('#ffffff', 0.10); ctx.lineWidth = 2.5;
        ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
      }
      // nós (conexões)
      for(const n of pipes.nodes){
        ctx.beginPath(); ctx.fillStyle = toRGBA('#ffffff', 0.12);
        ctx.arc(n.x, n.y, 2.2, 0, Math.PI*2); ctx.fill();
      }
      // pacotes animados
      const speedBase = parseFloat(canvas.getAttribute('data-speed')||'0.9');
      const s = (isNaN(speedBase)?0.9:speedBase);
      for(const p of pipes.packets){
        p.t += p.sp * s * p.dir;
        if(p.t>1) p.t = 0; if(p.t<0) p.t = 1;
        let x=0, y=0;
        if(p.axis==='h'){
          y = pipes.rows[p.idx];
          x = p.t * width;
        } else {
          x = pipes.cols[p.idx];
          y = p.t * height;
        }
        // brilho do pulso
        const grad = ctx.createRadialGradient(x,y,0, x,y,6);
        grad.addColorStop(0, toRGBA(brand, 0.45));
        grad.addColorStop(1, toRGBA(brand, 0.00));
        ctx.beginPath(); ctx.fillStyle = grad; ctx.arc(x,y, 6, 0, Math.PI*2); ctx.fill();
        // chevron discreto na direção
        ctx.beginPath();
        ctx.strokeStyle = toRGBA('#ffffff', 0.20);
        ctx.lineWidth = 1.2;
        if(p.axis==='h'){
          const dx = p.dir>0? 8:-8;
          ctx.moveTo(x - dx, y - 3); ctx.lineTo(x, y); ctx.lineTo(x - dx, y + 3);
        } else {
          const dy = p.dir>0? 8:-8;
          ctx.moveTo(x - 3, y - dy); ctx.lineTo(x, y); ctx.lineTo(x + 3, y - dy);
        }
        ctx.stroke();
      }
    }

    // ===== jet (jato de ar com streamlines curvadas e pulsos) =====
    const jet = { paths: [], pulses: [] };
    function bezier(p0,p1,p2,p3,t){
      const it = 1-t, it2 = it*it, t2 = t*t;
      const x = it2*it*p0.x + 3*it2*t*p1.x + 3*it*t2*p2.x + t2*t*p3.x;
      const y = it2*it*p0.y + 3*it2*t*p1.y + 3*it*t2*p2.y + t2*t*p3.y;
      return {x,y};
    }
    function resetJet(){
      jet.paths = []; jet.pulses = [];
      // origem (bocal) relativa
      const sxAttr = parseFloat(canvas.getAttribute('data-sx')||'0.10');
      const syAttr = parseFloat(canvas.getAttribute('data-sy')||'0.72');
      const angDeg = parseFloat(canvas.getAttribute('data-angle')||'15'); // graus em relação ao eixo X
      const sx = (isNaN(sxAttr)?0.10:sxAttr) * width;
      const sy = (isNaN(syAttr)?0.72:syAttr) * height;
      const ang = (isNaN(angDeg)?15:angDeg) * Math.PI/180;
      const dir = { x: Math.cos(ang), y: -Math.sin(ang) };
      const countAttr = parseInt(canvas.getAttribute('data-streams')||'12',10);
      const count = Math.max(6, Math.min(20, isNaN(countAttr)?12:countAttr));
      const len = Math.sqrt(width*width + height*height) * 0.9; // caminho longo para fora da tela
      const densityAttr = parseFloat(canvas.getAttribute('data-density')||'1');
      const density = isNaN(densityAttr)? 1 : Math.max(0.6, Math.min(1.8, densityAttr));
      // gera caminhos
      for(let i=0;i<count;i++){
        const spread = (i - (count-1)/2) / (count-1); // -0.5..0.5
        const jitter = (Math.random()*2-1) * 0.06; // variação de curvatura
        const p0 = { x: sx + spread*14, y: sy + spread*22 };
        const end = { x: sx + dir.x*len + spread*60, y: sy + dir.y*len + spread*40 };
        // pontos de controle com curvatura suave
        const cp1 = { x: p0.x + dir.x* (len*0.18) + spread*60, y: p0.y + dir.y*(len*0.18) - Math.sign(spread)*40 };
        const cp2 = { x: p0.x + dir.x* (len*0.55) + (spread*120), y: p0.y + dir.y*(len*0.55) + (jitter*height) };
        // amostras do bezier
        const pts = []; const segs = 90;
        for(let s=0;s<=segs;s++){
          const t = s/segs; pts.push(bezier(p0,cp1,cp2,end,t));
        }
        jet.paths.push({ pts, color: (i%3? toRGBA(brand, 0.18): toRGBA('#ffffff', 0.10)), lw: 1.1 + Math.random()*0.8 });
        // adicionar 1-2 pulsos por caminho
        const pulses = 1 + (Math.random()<0.35?1:0);
        for(let k=0;k<pulses;k++){
          jet.pulses.push({ path: jet.paths.length-1, t: Math.random(), sp: (0.004 + Math.random()*0.006) });
        }
      }
      // limpar
      ctx.clearRect(0,0,width,height);
    }
    function drawJet(){
      // véu sutil
      ctx.fillStyle = toRGBA(dark, 0.05); ctx.fillRect(0,0,width,height);
      // desenha streamlines
      for(const line of jet.paths){
        ctx.beginPath();
        for(let i=0;i<line.pts.length;i++){
          const p = line.pts[i]; if(i===0) ctx.moveTo(p.x,p.y); else ctx.lineTo(p.x,p.y);
        }
        ctx.strokeStyle = line.color; ctx.lineWidth = line.lw; ctx.lineCap = 'round'; ctx.lineJoin='round';
        ctx.stroke();
      }
      // pulsos ao longo das linhas
      const base = parseFloat(canvas.getAttribute('data-speed')||'0.85');
      const speed = (isNaN(base)?0.85:base);
      for(const pl of jet.pulses){
        pl.t += pl.sp * speed; if(pl.t>1) pl.t = 0;
        const path = jet.paths[pl.path]; if(!path) continue;
        const idx = Math.floor(pl.t * (path.pts.length-1));
        const p = path.pts[idx];
        const grad = ctx.createRadialGradient(p.x,p.y,0, p.x,p.y,6);
        grad.addColorStop(0, toRGBA(brand, 0.45));
        grad.addColorStop(1, toRGBA(brand, 0.00));
        ctx.beginPath(); ctx.fillStyle = grad; ctx.arc(p.x,p.y, 6, 0, Math.PI*2); ctx.fill();
      }
    }

    // ===== leaves (folhas soprando lentamente) =====
    const leaves = [];
    let tLeaves = 0;
    function resetLeaves(){
      leaves.length = 0;
      // densidade e velocidade
      const densAttr = parseFloat(canvas.getAttribute('data-density')||'1');
      const density = isNaN(densAttr)? 1 : Math.max(0.5, Math.min(2.0, densAttr));
      const baseCount = Math.max(12, Math.min(44, Math.floor((width*height)/38000 * density)));
      // cor customizável
      const leafColorAttr = (canvas.getAttribute('data-leaf-color')||'').trim();
      const leafMain = leafColorAttr ? toRGBA(leafColorAttr, 0.22) : toRGBA('#3FA471', 0.22);
      const leafEdge = leafColorAttr ? toRGBA(leafColorAttr, 0.30) : toRGBA('#2D8C5F', 0.30);
      for(let i=0;i<baseCount;i++){
        const s = 0.7 + Math.random()*1.3; // escala
        leaves.push({
          x: Math.random()*width,
          y: height*(0.18 + Math.random()*0.64),
          vx: 0.4 + Math.random()*0.6,
          vy: (Math.random()*0.4 - 0.2),
          s,
          ang: Math.random()*Math.PI*2,
          av: (Math.random()*0.004 - 0.002),
          swayA: Math.random()*Math.PI*2,
          swayF: 0.8 + Math.random()*1.2,
          main: leafMain,
          edge: leafEdge
        });
      }
      // limpar
      ctx.clearRect(0,0,width,height);
      tLeaves = 0;
    }
    function drawLeafShape(cx, cy, angle, scale, mainCol, edgeCol){
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(angle);
      ctx.scale(scale, scale);
      const w = 10, h = 20; // forma básica da folha (pingo)
      // corpo
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(w*0.9, -h*0.55, w*0.6, -h);
      ctx.quadraticCurveTo(0, -h*0.85, -w*0.6, -h);
      ctx.quadraticCurveTo(-w*0.9, -h*0.55, 0, 0);
      ctx.fillStyle = mainCol;
      ctx.fill();
      // contorno leve
      ctx.strokeStyle = edgeCol;
      ctx.lineWidth = 0.8;
      ctx.stroke();
      // nervura central
      ctx.beginPath();
      ctx.strokeStyle = toRGBA('#ffffff', 0.18);
      ctx.lineWidth = 0.8;
      ctx.moveTo(0, -h);
      ctx.lineTo(0, 0);
      ctx.stroke();
      ctx.restore();
    }
    function drawLeaves(){
      // fundo mais limpo (sem trilha longa), com véu muito sutil
      ctx.fillStyle = toRGBA(dark, 0.035);
      ctx.fillRect(0,0,width,height);
      const spAttr = parseFloat(canvas.getAttribute('data-speed')||'0.6');
      const speed = (isNaN(spAttr)?0.6:Math.max(0.2, Math.min(1.2, spAttr)));
      tLeaves += 0.0025 * speed;
      for(const p of leaves){
        // campo de vento suave com variação vertical e rajadas leves
        const nx = p.x/width, ny = p.y/height;
        const windX = 0.35 + 0.25*Math.sin(ny*2.0 + tLeaves*1.2) + 0.10*Math.sin((nx+ny)*3.0 + tLeaves*2.2);
        const windY = 0.08*Math.sin(nx*2.6 + tLeaves*1.6) + 0.05*Math.cos(ny*2.1 + tLeaves*1.4);
        // atualização de velocidade
        p.vx = p.vx*0.92 + windX*0.55;
        p.vy = p.vy*0.92 + (0.02 + windY*0.6); // leve gravidade + oscilações
        // posição
        p.x += p.vx * speed;
        p.y += p.vy * speed;
        // rotação com leve "flutter"
        p.ang += p.av + 0.015*Math.sin(tLeaves*4*p.swayF + p.swayA);
        // respawn se sair da tela
        const margin = 16;
        if(p.x > width + margin || p.y > height + margin || p.y < -margin){
          p.x = -margin - Math.random()*40;
          p.y = height*(0.18 + Math.random()*0.64);
          p.vx = 0.3 + Math.random()*0.5;
          p.vy = (Math.random()*0.3 - 0.15);
          p.ang = Math.random()*Math.PI*2;
        }
        // desenho
        drawLeafShape(p.x, p.y, p.ang, p.s, p.main, p.edge);
      }
    }

    // pausa por visibilidade
    const hero = document.getElementById('hero');
    const io = ('IntersectionObserver' in window && hero) ? new IntersectionObserver((entries)=>{
      const en = entries[0]; const shouldRun = en.isIntersecting && !mq.matches;
      if(shouldRun && !running){ running = true; loop(); }
      else if(!shouldRun && running){ running = false; cancelAnimationFrame(rafId); }
    }, {threshold: 0.05}) : null;
    if(io && hero) io.observe(hero);

    // resize debounce
    let rto; function onResize(){ clearTimeout(rto); rto = setTimeout(resize, 120); }
    window.addEventListener('resize', onResize, {passive:true});

    // start
    resize(); if(!mq.matches){ running = true; loop(); }
    mq.addEventListener?.('change', ()=>{ if(mq.matches){ running=false; cancelAnimationFrame(rafId);} else if(!running){ running=true; loop(); }});
  })();

  // Destaque do link ativo no menu (scrollspy simples por path)
  (function(){
    if(!nav) return;
    const path = location.pathname.replace(/\/+/g,'/').replace(/\/?$/,'');
    const base = '/arcompi_init';
    const current = path.startsWith(base) ? path.slice(base.length) : path;
    const slug = current.split('/').filter(Boolean)[0] || 'home';
    [...nav.querySelectorAll('a')].forEach(a=>{
      const href = a.getAttribute('href') || '';
      if(href.endsWith('/'+slug) || (slug==='home' && /\/home$/.test(href))){ a.classList.add('active'); }
    });
  })();

  // Smooth scroll para âncoras internas
  document.addEventListener('click', (e)=>{
    const a = e.target.closest('a[href^="#"]');
    if(a){
      const id = a.getAttribute('href');
      const el = document.querySelector(id);
      if(el){
        e.preventDefault();
        // ajuste por header sticky e subnav da página de serviços
        const header = document.querySelector('.site-header');
        const subnav = document.querySelector('.servicos-subnav');
        const rect = el.getBoundingClientRect();
        const offset = (window.pageYOffset || document.documentElement.scrollTop) + rect.top;
        const gap = (header?.offsetHeight || 0) + (subnav?.offsetHeight || 0) + 12;
        window.scrollTo({ top: Math.max(0, offset - gap), behavior: 'smooth' });
      }
    }
  }, {passive:false});

  // Scroll reveal com IntersectionObserver
  (function(){
    const candidates = document.querySelectorAll('.hero-copy, .hero-media, .card, .highlight-inner, .feature-list li, .badges li, .container h1, .container h2, .container h3, details, blockquote');
    const els = [...candidates];
    els.forEach((el,idx)=>{
      el.classList.add('reveal');
      el.style.transitionDelay = (idx%6)*40 + 'ms';
    });
    if('IntersectionObserver' in window){
      const io = new IntersectionObserver((entries)=>{
        entries.forEach(en=>{ if(en.isIntersecting){ en.target.classList.add('is-in'); io.unobserve(en.target);} });
      }, {threshold: 0.12, rootMargin:'0px 0px -10% 0px'});
      els.forEach(el=> io.observe(el));
    } else {
      // Fallback
      els.forEach(el=> el.classList.add('is-in'));
    }
  })();

  // Slider com controles, dots e auto-rotate (suporta múltiplas instâncias)
  (function(){
    const sliders = document.querySelectorAll('[data-slider]');
    if(!sliders.length) return;
    sliders.forEach((slider)=>{
      // itens antes de inserir controles
      const items = [...slider.children].filter(el=> el.nodeType===1);
      if(!items.length) return;
      slider.setAttribute('tabindex','0'); // permite teclado quando focado
      let i = 0;
      items.forEach((el,idx)=>{ el.dataset.slide = String(idx); el.style.display = idx===0? 'block':'none'; });

      // Controles dentro do contêiner
      const controls = document.createElement('div');
      controls.className = 'slider-controls';
      const prev = document.createElement('button'); prev.type='button'; prev.className='slider-prev'; prev.setAttribute('aria-label','Anterior'); prev.textContent = '‹';
      const next = document.createElement('button'); next.type='button'; next.className='slider-next'; next.setAttribute('aria-label','Próximo'); next.textContent = '›';
      controls.appendChild(prev); controls.appendChild(next);
      // Dots
      const dots = document.createElement('div'); dots.className='slider-dots';
      items.forEach((_,idx)=>{ const b=document.createElement('button'); b.type='button'; b.className='dot'; b.setAttribute('aria-label','Ir para slide '+(idx+1)); dots.appendChild(b); });
      controls.appendChild(dots);
      slider.appendChild(controls);

      function render(){
        items.forEach((el,idx)=>{ el.style.display = idx===i? 'block':'none'; });
        const ds = [...dots.children]; ds.forEach((d,idx)=> d.classList.toggle('active', idx===i));
      }
      function go(n){ i = (n+items.length)%items.length; render(); }
      prev.addEventListener('click', ()=>{ stop(); go(i-1); start(); });
      next.addEventListener('click', ()=>{ stop(); go(i+1); start(); });
      dots.addEventListener('click',(e)=>{ const b=e.target.closest('button.dot'); if(!b) return; const idx=[...dots.children].indexOf(b); stop(); go(idx); start(); });

      // Teclado e toque (só quando o slider tem foco)
      slider.addEventListener('keydown',(e)=>{ if(e.key==='ArrowLeft'){ stop(); go(i-1); start(); } if(e.key==='ArrowRight'){ stop(); go(i+1); start(); } });
      let sx=0; slider.addEventListener('touchstart',(e)=>{ sx=e.changedTouches[0].clientX; }, {passive:true});
      slider.addEventListener('touchend',(e)=>{ const dx = e.changedTouches[0].clientX - sx; if(Math.abs(dx)>30){ stop(); go(i + (dx<0?1:-1)); start(); } }, {passive:true});

      // Auto-rotate por instância
      const intervalAttr = parseInt(slider.getAttribute('data-interval')||'4500',10);
      const interval = isNaN(intervalAttr)? 4500 : Math.max(2500, intervalAttr);
      let t; function start(){ t = setInterval(()=>{ go(i+1); }, interval); }
      function stop(){ if(t) clearInterval(t); }
      render(); start();
      // Pause/resume on hover
      slider.addEventListener('mouseenter', stop, {passive:true});
      slider.addEventListener('mouseleave', start, {passive:true});
    });
  })();

  // Envio AJAX do formulário de contato
  (function(){
    const form = document.querySelector('.contact-form');
    if(!form) return;
    const msg = document.createElement('div'); msg.className='form-msg'; form.prepend(msg);
    form.addEventListener('submit', async (e)=>{
      e.preventDefault();
      msg.textContent = '';
      msg.className = 'form-msg';
      const btn = form.querySelector('button[type="submit"]');
      if(btn){ btn.disabled = true; btn.dataset.old = btn.textContent; btn.textContent = 'Enviando…'; }
      const fd = new FormData(form);
      // Validação simples
      const nome = (fd.get('nome')||'').toString().trim();
      const email = (fd.get('email')||'').toString().trim();
      const assunto = (fd.get('assunto')||'').toString().trim();
      const mensagem = (fd.get('mensagem')||'').toString().trim();
      const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      if(!nome || !emailOk || !assunto || !mensagem){
        msg.textContent = 'Verifique os campos obrigatórios e o e-mail.';
        msg.classList.add('error'); if(btn){ btn.disabled=false; btn.textContent=btn.dataset.old||'Enviar'; } return;
      }
      try{
        const res = await fetch(form.action, { method: 'POST', body: fd, headers: { 'X-Requested-With':'fetch' } });
        const data = await res.json().catch(()=>({ok:false, message:'Erro inesperado.'}));
        if(data.ok){
          msg.textContent = data.message || 'Mensagem enviada com sucesso.';
          msg.classList.add('success');
          form.reset();
        } else {
          msg.textContent = data.message || 'Não foi possível enviar agora. Tente mais tarde.';
          msg.classList.add('error');
        }
      } catch(err){
        msg.textContent = 'Falha de rede. Tente novamente.';
        msg.classList.add('error');
      } finally {
        if(btn){ btn.disabled=false; btn.textContent=btn.dataset.old||'Enviar'; }
      }
    });
  })();

  // Contadores animados (stats)
  (function(){
    const els = document.querySelectorAll('.stat-value[data-count]');
    if(!els.length) return;
    const duration = 1400;
    function animate(el){
      const target = Number(el.getAttribute('data-count')||'0');
      const start = performance.now();
      function tick(now){
        const p = Math.min(1,(now-start)/duration);
        const eased = p<.5 ? 2*p*p : -1+(4-2*p)*p; // easeInOutQuad
        el.textContent = Math.floor(target*eased).toLocaleString('pt-BR');
        if(p<1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    }
    if('IntersectionObserver' in window){
      const io = new IntersectionObserver((entries)=>{
        entries.forEach(en=>{ if(en.isIntersecting){ animate(en.target); io.unobserve(en.target);} });
      }, {threshold:.6});
      els.forEach(el=> io.observe(el));
    } else {
      els.forEach(el=> animate(el));
    }
  })();

  // Botão "Voltar ao topo" (exibe acima do WhatsApp)
  (function(){
    const btnWrap = document.getElementById('to-top');
    if(!btnWrap) return;
    const btn = btnWrap.querySelector('button');
    function onScroll(){
      const y = window.scrollY || document.documentElement.scrollTop;
      btnWrap.classList.toggle('show', y > 300);
    }
    window.addEventListener('scroll', onScroll, {passive:true});
    onScroll();
    btn?.addEventListener('click', ()=>{
      window.scrollTo({top: 0, behavior: 'smooth'});
    });
  })();

  // Faixa de mini-banners com autoscroll contínuo (hero) — robusto contra gaps
  (function(){
    const tracks = document.querySelectorAll('.thumb-track[data-autoscroll="true"]');
    if(!tracks.length) return;

    tracks.forEach((track)=>{
      const wrap = track.parentElement;
      if(!wrap) return;
      let clone = null;
      let x = 0;
      let w = 0;
      let last = 0;
      let running = false;
      let raf;

      // velocidade configurável
      const speedAttr = parseFloat(track.getAttribute('data-speed')||'28');
      const pxPerSec = isNaN(speedAttr) ? 28 : Math.max(10, Math.min(80, speedAttr));

      // 1) Pré-carregar todas as imagens (evita medir com largura 0)
      const imgs = [...track.querySelectorAll('img')];
      function preloadOne(src){
        return new Promise((resolve)=>{ const im = new Image(); im.onload = im.onerror = resolve; im.src = src; });
      }
      async function preloadAll(){
        if(!imgs.length) return;
        // Se possível, evitar lazy no hero
        imgs.forEach(img => { img.loading = 'eager'; img.decoding = 'async'; img.setAttribute('fetchpriority','high'); });
        await Promise.all(imgs.map(img => preloadOne(img.currentSrc || img.src)));
      }

      // 2) Construir clone e medir
      function buildClone(){
        if(clone) clone.remove();
        clone = track.cloneNode(true);
        clone.removeAttribute('data-autoscroll'); // evita recursão
        wrap.appendChild(clone);
      }
      function measure(){
        w = Math.ceil(track.scrollWidth);
        // manter posição dentro do novo comprimento (evita “buracos”)
        if(w > 0){
          const progress = ((-x) % w + w) % w;
          x = -progress;
          track.style.transform = `translateX(${x}px)`;
          if(clone) clone.style.transform = `translateX(${x + w}px)`;
        }
      }

      // 3) Loop
      function step(now){
        if(!running) return;
        const dt = Math.min(0.05, (now - last)/1000);
        last = now;

        // desloca
        x -= pxPerSec * dt;

        // recalibra se a largura mudou (ex.: responsivo ou fontes/imagens ajustaram)
        const newW = Math.ceil(track.scrollWidth);
        if(newW && newW !== w){
          w = newW;
          const progress = ((-x) % w + w) % w;
          x = -progress;
        }

        if(w > 0 && -x >= w) x += w;

        track.style.transform = `translateX(${x}px)`;
        if(clone) clone.style.transform = `translateX(${x + w}px)`;

        raf = requestAnimationFrame(step);
      }

      // 4) Init assíncrono
      async function init(){
        await preloadAll();
        buildClone();
        measure();
        last = performance.now();
        running = true;
        raf = requestAnimationFrame(step);
      }

      // pausa no hover
      wrap.addEventListener('mouseenter', ()=>{ running=false; cancelAnimationFrame(raf); }, {passive:true});
      wrap.addEventListener('mouseleave', ()=>{ if(!running){ running=true; last=performance.now(); raf=requestAnimationFrame(step);} }, {passive:true});

      // Observa mudanças de tamanho do track (quando imagens/viewport alteram)
      if('ResizeObserver' in window){
        const ro = new ResizeObserver(()=> measure());
        ro.observe(track);
      } else {
        window.addEventListener('resize', ()=>{ measure(); }, {passive:true});
      }

      init();
    });
  })();

  // Canvas de fundo com pontos animados (leve e harmonizado)
  (function initDotsCanvas(){
  const canvases = document.querySelectorAll('canvas.bg-canvas[data-effect="dots"]');
    if(!canvases.length) return;

    const prefersReduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    canvases.forEach((cv)=>{
      const ctx = cv.getContext('2d');
      let dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
      let W = 0, H = 0, rafId = null;
      const dots = [];
      const base = getComputedStyle(document.documentElement);
      const c1 = base.getPropertyValue('--brand-primary')?.trim() || '#106CB4';
      const c2 = '#0A2541';

      function resize(){
        const rect = cv.getBoundingClientRect();
        W = Math.floor(rect.width); H = Math.floor(rect.height);
        cv.width = Math.floor(W * dpr); cv.height = Math.floor(H * dpr);
        cv.style.width = W+'px'; cv.style.height = H+'px';
        ctx.setTransform(dpr,0,0,dpr,0,0);
        seed();
      }

      function seed(){
        dots.length = 0;
        const count = Math.max(28, Math.floor((W*H)/60000)); // densidade leve
        for(let i=0;i<count;i++){
          dots.push({
            x: Math.random()*W,
            y: Math.random()*H,
            r: 1 + Math.random()*1.6,
            vx: (Math.random()*0.6+0.2) * (Math.random()<0.5?-1:1),
            vy: (Math.random()*0.6+0.2) * (Math.random()<0.5?-1:1),
            c: Math.random()<0.55 ? c1 : c2,
            a: 0.18 + Math.random()*0.15
          });
        }
      }

      function step(){
        ctx.clearRect(0,0,W,H);
        // linhas sutis
        for(let i=0;i<dots.length;i++){
          for(let j=i+1;j<dots.length;j++){
            const dx = dots[i].x - dots[j].x;
            const dy = dots[i].y - dots[j].y;
           
            const d2 = dx*dx + dy*dy;
            if(d2 < 140*140){
              const opa = Math.max(0, 0.06 - d2/(140*140)*0.06);
              if(opa>0){
                ctx.strokeStyle = `rgba(16,108,180,${opa})`;
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(dots[i].x, dots[i].y);
                ctx.lineTo(dots[j].x, dots[j].y);
                ctx.stroke();
              }
            }
          }
        }
        // pontos
        dots.forEach(d=>{
          ctx.fillStyle = hexToRgba(d.c, d.a);
          ctx.beginPath();
          ctx.arc(d.x, d.y, d.r, 0, Math.PI*2);
          ctx.fill();

          if(!prefersReduce){
            d.x += d.vx; d.y += d.vy;
            if(d.x < -10) d.x = W+10; if(d.x > W+10) d.x = -10;
            if(d.y < -10) d.y = H+10; if(d.y > H+10) d.y = -10;
          }
        });
        rafId = requestAnimationFrame(step);
      }

      function hexToRgba(hex, a){
        const h = hex.replace('#','');
        const r = parseInt(h.length===3 ? h[0]+h[0] : h.slice(0,2),16);
        const g = parseInt(h.length===3 ? h[1]+h[1] : h.slice(2,4),16);
        const b = parseInt(h.length===3 ? h[2]+h[2] : h.slice(4,6),16);
        return `rgba(${r},${g},${b},${a})`;
      }

      const ro = new ResizeObserver(resize);
      ro.observe(cv);
      resize();
      rafId = requestAnimationFrame(step);

      cv.addEventListener('visibilitychange', ()=>{
        if(document.hidden){ cancelAnimationFrame(rafId); }
        else { rafId = requestAnimationFrame(step); }
      });
    });
  })();

  
})();

// Subnav da página de serviços: scrollspy e destaque ativo
(function(){
  const subnav = document.querySelector('.servicos-subnav .subnav-track');
  if(!subnav) return;
  const links = [...subnav.querySelectorAll('a[href^="#"]')];
  if(!links.length) return;
  const sections = links.map(a=> document.querySelector(a.getAttribute('href'))).filter(Boolean);
  function setActive(id){ links.forEach(a=> a.classList.toggle('active', a.getAttribute('href')===`#${id}`)); }
  // Observer para alterar ativo conforme scroll
  if('IntersectionObserver' in window){
    const headerH = document.querySelector('.site-header')?.offsetHeight || 0;
    const subH = document.querySelector('.servicos-subnav')?.offsetHeight || 0;
    const io = new IntersectionObserver((entries)=>{
      entries.forEach(en=>{
        if(en.isIntersecting){ setActive(en.target.id); }
      });
    }, { threshold: 0.4, rootMargin: `-${headerH+subH+20}px 0px -40% 0px` });
    sections.forEach(sec=> io.observe(sec));
  }
  // Clique: scroll com ajuste (já coberto pelo handler global) – apenas fecha nav mobile se aberta
  subnav.addEventListener('click',(e)=>{
    const a = e.target.closest('a'); if(!a) return;
    const nav = document.getElementById('nav'); const hamb = document.querySelector('.hamb');
    if(nav?.classList.contains('open')){ nav.classList.remove('open'); hamb?.setAttribute('aria-expanded','false'); }
  });

  // Se entrar com hash direto na URL, ajustar a rolagem para compensar cabeçalhos
  window.addEventListener('load', ()=>{
    if(location.hash){
      const el = document.querySelector(location.hash);
      if(el){
        const header = document.querySelector('.site-header');
        const sub = document.querySelector('.servicos-subnav');
        const rect = el.getBoundingClientRect();
        const offset = (window.pageYOffset || document.documentElement.scrollTop) + rect.top;
        const gap = (header?.offsetHeight || 0) + (sub?.offsetHeight || 0) + 12;
        window.scrollTo({ top: Math.max(0, offset - gap) });
      }
    }
  }, { once: true });
})();

// Toggle "ver mais" em listas colapsáveis dos serviços
(function(){
  const wraps = document.querySelectorAll('#o-que-fazemos .collapsible');
  wraps.forEach((w)=>{
    const btn = w.querySelector('.reveal-toggle');
    if(!btn) return;
    const inner = w.querySelector('.collapsible-inner');
    if(!inner) return;
    // estado inicial
    w.classList.add('is-collapsed');
    btn.addEventListener('click', ()=>{
      const collapsed = w.classList.toggle('is-collapsed');
      btn.setAttribute('aria-expanded', String(!collapsed));
      btn.textContent = collapsed ? 'Ver mais' : 'Ver menos';
    });
  });
})();

// Carrossel de depoimentos - rolagem automática infinita com suporte para arrastar
(function autoTestimonials(){
  const roots = document.querySelectorAll('.testimonial-carousel');
  if (!roots.length) return;

  roots.forEach(init);

  function init(root){
    const track = root.querySelector('.testimonial-track');
    if (!track) return;

    const speed = parseFloat(root.getAttribute('data-speed') || '0.6'); 
    let tx = 0, raf = null, paused = false, gap = 0;
    
    // Variáveis para controle de arrasto
    let isDragging = false;
    let startX = 0;
    let currentX = 0;
    let lastDelta = 0;
    let startTime = 0;
    let velocity = 0;
    let initialTx = 0;

    // Duplicar os cards até cobrir pelo menos 2x a largura do carrossel
    const items = Array.from(track.children);
    if (!items.length) return;

    requestAnimationFrame(() => {
      gap = parseFloat(getComputedStyle(track).gap || '0');
      const originals = Array.from(track.children);
      
      // Duplicar cards para rolagem infinita
      while (track.scrollWidth < root.offsetWidth * 2) {
        originals.forEach(el => track.appendChild(el.cloneNode(true)));
      }
      
      start();
    });

    // Pausa no hover (removido para permitir arrasto)
    // root.addEventListener('pointerenter', () => { paused = true; });
    // root.addEventListener('pointerleave', () => { paused = false; });

    // Eventos para suporte de arrasto
    track.addEventListener('mousedown', startDrag);
    track.addEventListener('touchstart', e => {
      const touch = e.touches[0];
      startDrag({ clientX: touch.clientX });
    }, { passive: true });
    
    window.addEventListener('mousemove', drag);
    window.addEventListener('touchmove', e => {
      if (!isDragging) return;
      const touch = e.touches[0];
      drag({ clientX: touch.clientX });
      e.preventDefault(); // Previne scroll da página
    }, { passive: false });
    
    window.addEventListener('mouseup', endDrag);
    window.addEventListener('touchend', endDrag);
    window.addEventListener('mouseleave', endDrag);
    
    window.addEventListener('resize', normalize);

    function start(){
      cancelAnimationFrame(raf);
      const step = () => {
        if (!isDragging && !paused) {
          tx -= speed;
          track.style.transform = `translateX(${tx}px)`;
          shiftIfNeeded();
        }
        raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    }

    function startDrag(e) {
      if (e.button > 0) return;
      
      isDragging = true;
      paused = true;
      startX = e.clientX;
      currentX = startX;
      initialTx = tx;
      startTime = Date.now();
      velocity = 0;
      lastDelta = 0;
      
      // Parar animação e definir transição para nenhuma
      cancelAnimationFrame(raf);
      track.style.transition = 'none';
      
      // Evitar seleção de texto durante arrasto
      track.style.userSelect = 'none';
      
      // Mudar cursor
      track.style.cursor = 'grabbing';
    }
    
    function drag(e) {
      if (!isDragging) return;
      
      const now = Date.now();
      const elapsed = now - startTime;
      
      currentX = e.clientX;
      const delta = currentX - startX;
      
      // Aplicar movimento com resistência nas extremidades
      tx = initialTx + delta;
      track.style.transform = `translateX(${tx}px)`;
      
      // Calcular velocidade para inércia
      if (elapsed > 0) {
        const newDelta = delta - lastDelta;
        velocity = 0.8 * (newDelta / elapsed) + 0.2 * velocity;
        lastDelta = delta;
        startTime = now;
      }
    }
    
    function endDrag() {
      if (!isDragging) return;
      
      isDragging = false;
      
      // Restaurar estilos
      track.style.userSelect = '';
      track.style.cursor = '';
      
      // Aplicar inércia
      const speed = velocity * 24; // Ajuste conforme necessário
      
      if (Math.abs(speed) > 0.5) {
        // Se a velocidade for significativa, aplicar efeito de inércia
        let momentum = 0;
        const decelerate = () => {
          momentum += speed;
          tx = initialTx + momentum;
          
          // Desacelerar
          velocity *= 0.95;
          
          track.style.transform = `translateX(${tx}px)`;
          shiftIfNeeded();
          
          if (Math.abs(velocity) > 0.1) {
            requestAnimationFrame(decelerate);
          } else {
            // Quando a inércia terminar, voltar à animação normal
            paused = false;
            start();
          }
        };
        
        requestAnimationFrame(decelerate);
      } else {
        // Se movimento foi muito lento, voltar direto à animação
        paused = false;
        start();
      }
    }

    function shiftIfNeeded(){
      const first = track.firstElementChild;
      if (!first) return;
      const wrapRect = root.getBoundingClientRect();
      const firstRect = first.getBoundingClientRect();
      if (firstRect.right < wrapRect.left - 1) {
        const w = firstRect.width + gap;
        track.appendChild(first);
        tx += w;
        track.style.transform = `translateX(${tx}px)`;
      }
      
      // Também verificar no outro sentido (se arrastar para a direita)
      const last = track.lastElementChild;
      if (!last) return;
      const lastRect = last.getBoundingClientRect();
      if (lastRect.left > wrapRect.right + 1) {
        const w = last.getBoundingClientRect().width + gap;
        track.prepend(last);
        tx -= w;
        track.style.transform = `translateX(${tx}px)`;
      }
    }

    function normalize(){
      tx = 0;
      track.style.transition = 'none';
      track.style.transform = 'translateX(0)';
      void(track.offsetWidth); // força reflow
      gap = parseFloat(getComputedStyle(track).gap || '0');
    }
  }
})();

// Mobile-only Carousel for Banner
/*
(function() {
  const banner = document.querySelector('.banner-carousel');
  if (!banner) return;

  const track = banner.querySelector('.thumb-track');
  const items = banner.querySelectorAll('.thumb');
  if (items.length <= 1) return;

  let currentIndex = 0;
  let intervalId = null;
  let dotsContainer = null;
  let isMobile = false;

  function goToSlide(index, smooth = true) {
    if (!track || !isMobile) return;
    currentIndex = (index + items.length) % items.length;
    const offset = -currentIndex * 100;
    track.style.transition = smooth ? 'transform 0.4s ease-in-out' : 'none';
    track.style.transform = `translateX(${offset}%)`;
    updateDots();
  }

  function createDots() {
    if (dotsContainer) dotsContainer.remove();
    dotsContainer = document.createElement('div');
    dotsContainer.className = 'slider-dots';
    items.forEach((_, index) => {
      const dot = document.createElement('button');
      dot.type = 'button';
      dot.className = 'dot';
      dot.setAttribute('aria-label', `Ir para slide ${index + 1}`);
      dot.addEventListener('click', () => {
        goToSlide(index);
        startAutoplay(); // Restart timer on manual navigation
      });
      dotsContainer.appendChild(dot);
    });
    banner.appendChild(dotsContainer);
  }

  function updateDots() {
    if (!dotsContainer) return;
    const dots = dotsContainer.querySelectorAll('.dot');
    dots.forEach((dot, index) => {
      dot.classList.toggle('active', index === currentIndex);
    });
  }

  function startAutoplay() {
    stopAutoplay();
    intervalId = setInterval(() => {
      goToSlide(currentIndex + 1);
    }, 4500);
  }

  function stopAutoplay() {
    clearInterval(intervalId);
  }

  function setupMobile() {
    if (isMobile) return;
    isMobile = true;
    
    banner.classList.add('is-mobile-slider');
    createDots();
    goToSlide(0, false);
    startAutoplay();
    
    // Basic swipe support
    let touchstartX = 0;
    track.addEventListener('touchstart', e => {
        touchstartX = e.changedTouches[0].screenX;
        stopAutoplay();
    }, { passive: true });

    track.addEventListener('touchend', e => {
        const touchendX = e.changedTouches[0].screenX;
        const delta = touchendX - touchstartX;
        if (Math.abs(delta) > 50) { // Threshold
            if (delta < 0) {
                goToSlide(currentIndex + 1);
            } else {
                goToSlide(currentIndex - 1);
            }
        }
        startAutoplay();
    }, { passive: true });
  }

  function destroyMobile() {
    if (!isMobile) return;
    isMobile = false;
    
    banner.classList.remove('is-mobile-slider');
    if (dotsContainer) dotsContainer.remove();
    dotsContainer = null;
    track.style.transform = '';
    track.style.transition = '';
    stopAutoplay();
  }

  function checkBreakpoint() {
    if (window.innerWidth < 768) {
      setupMobile();
    } else {
      destroyMobile();
    }
  }

  let resizeTimeout;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(checkBreakpoint, 250);
  });

  checkBreakpoint();
})();
*/

// Carrossel de logos de clientes (mobile-only, com autoscroll)
(function() {
  const root = document.querySelector('#clientes-e-depoimentos .clients-block');
  if (!root) return;

  const track = root.querySelector('.logos-grid');
  if (!track) return;

  let raf = null;
  let isMobile = false;

  function init() {
    const shouldBeMobile = window.innerWidth < 768;
    if (shouldBeMobile === isMobile) return; // No change

    isMobile = shouldBeMobile;

    if (raf) {
      cancelAnimationFrame(raf);
      raf = null;
    }
    track.style.transform = '';
    track.classList.remove('autoscroll');

    if (isMobile) {
      track.classList.add('autoscroll');
      const speed = 0.5;
      let tx = 0;
      
      const items = Array.from(track.children);
      if (items.length === 0) return;
      
      if (!track.dataset.cloned) {
        const originalItems = Array.from(track.children);
        while (track.scrollWidth < root.offsetWidth * 2.5) {
          originalItems.forEach(el => track.appendChild(el.cloneNode(true)));
        }
        track.dataset.cloned = 'true';
      }

      const step = () => {
        tx -= speed;
        const firstEl = track.firstElementChild;
        if (firstEl) {
          const elWidth = firstEl.offsetWidth + parseFloat(getComputedStyle(track).gap);
          if (tx <= -elWidth) {
            track.appendChild(firstEl);
            tx += elWidth;
          }
        }
        track.style.transform = `translateX(${tx}px)`;
        raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    }
  }

  let resizeTimeout;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(init, 250);
  });

  init();
})();
