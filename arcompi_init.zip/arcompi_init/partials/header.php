<?php /* Site header + nav */ ?>
<body>
<header class="site-header">
  <div class="container header-inner">
  <a class="logo" href="<?= BASE ?>/home">
      <img src="<?= BASE ?>/assets/img/logo-arcompi.webp" alt="Arcompi Compressores" width="250" height="110" />
    </a>
    <nav id="nav" class="nav">
      <a href="<?= BASE ?>/home">Home</a>
      <a href="<?= BASE ?>/sobre">Sobre</a>
      <a href="<?= BASE ?>/servicos">Serviços</a>
      <a href="<?= BASE ?>/contato">Contato</a>
      <a class="btn btn-primary btn-pulse" href="https://wa.me/5545991072777" target="_blank" rel="noopener">Fale Conosco</a>
    </nav>
        <button class="hamb" aria-label="Abrir menu" aria-controls="nav" aria-expanded="false">
      <span></span>
      <span></span>
      <span></span>
    </button>
  </div>
</header>
