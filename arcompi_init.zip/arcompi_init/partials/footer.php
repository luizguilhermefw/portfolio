<footer class="main-footer">
  <div class="container">
    <div class="footer-content">
      <div>
        <h4>Arcompi Compressores</h4>
        <p>Excelência em ar comprimido: venda, locação, instalação e manutenção.</p>
      </div>
      <div>
        <h4>Contato</h4>
        <ul class="list-unstyled">
          <li>Tel: <a href="tel:+55453306-2850">(45) 3306-2850</a></li>
          <li>WhatsApp: <a target="_blank" rel="noopener" href="https://wa.me/554591072777">Fale agora</a></li>
          <li>Email: <a href="mailto:contato@seu-dominio.com.br">contato@seu-dominio.com.br</a></li>
        </ul>
      </div>
      <div>
        <h4>Endereço</h4>
        <p>Rua Pio XII, 705 — Cascavel/PR</p>
        <p>Seg–Sex: 08h às 18h</p>
      </div>
    </div>
    <div class="footer-bottom">
      <small>© <?php echo date('Y'); ?> Arcompi Compressores. Todos os direitos reservados.</small>
      <small>Desenvolvido por <a href="https://www.luizguilhermefw.com.br" target="_blank" rel="noopener" class="dev-link">LF.Web</a></small>
    </div>
  </div>
</footer>
<div class="to-top-float" id="to-top" aria-hidden="true">
  <button type="button" aria-label="Voltar ao topo">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
      <polyline points="18 15 12 9 6 15"></polyline>
    </svg>
  </button>
  </div>
<div class="wp-float">
  <a aria-label="WhatsApp" href="https://wa.me/5545991072777" target="_blank" rel="noopener">
    <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" fill="currentColor">
      <title>WhatsApp</title>
      <path d="M20.52 3.48A11.77 11.77 0 0 0 12 0C5.37 0 0 5.37 0 12c0 2.12.55 4.12 1.52 5.86L0 24l6.31-1.65A11.95 11.95 0 0 0 12 24c6.63 0 12-5.37 12-12 0-3.2-1.24-6.2-3.48-8.52zM12 22.04c-1.95 0-3.86-.53-5.54-1.54l-.4-.24-3.74.98 1-3.64-.26-.42A9.96 9.96 0 0 1 2.02 12c0-5.5 4.48-9.98 9.98-9.98S22 6.5 22 12s-4.48 10.04-10 10.04zm5.74-7.6c-.31-.16-1.85-.91-2.14-1.02-.29-.11-.5-.16-.71.16-.2.31-.81 1.02-.99 1.24-.18.22-.36.25-.67.09-.31-.16-1.31-.48-2.49-1.53-.92-.82-1.54-1.84-1.72-2.15-.18-.31-.02-.48.14-.64.14-.14.31-.36.47-.56.16-.2.2-.34.31-.56.1-.22.05-.42-.02-.58-.07-.16-.71-1.72-.97-2.36-.26-.63-.52-.55-.71-.56-.18-.01-.4-.01-.62-.01-.22 0-.58.09-.89.42-.31.33-1.18 1.15-1.18 2.8 0 1.65 1.21 3.24 1.38 3.46.16.22 2.38 3.63 5.76 5.08.81.35 1.45.56 1.95.72.82.26 1.57.22 2.16.14.66-.1 2.03-.83 2.31-1.63.29-.8.29-1.48.2-1.63-.09-.15-.31-.24-.62-.4z"/>
    </svg>
  </a>
</div>
</body>
</html>