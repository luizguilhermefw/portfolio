<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['csrf'])) {
  $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
// Caminho base da aplicação na URL (ajuste conforme necessário)
if (!defined('BASE')) {
  define('BASE', '/arcompi_init');
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?= $title ?? 'Arcompi Compressores' ?></title>
  <meta name="description" content="Compressores de ar, automação pneumática, redes de ar, auditoria e assistência técnica autorizada em Cascavel e região." />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Red+Hat+Display:wght@400;500;700&display=swap" rel="stylesheet">
  <link rel="preload" href="<?= BASE ?>/assets/css/styles.css?v=<?= time() ?>" as="style" />
  <link rel="stylesheet" href="<?= BASE ?>/assets/css/styles.css?v=<?= time() ?>" />
  <link rel="icon" href="<?= BASE ?>/assets/img/logo-arcompi.webp" type="image/webp" />
  <meta property="og:title" content="Arcompi Compressores" />
  <meta property="og:description" content="Soluções completas em ar comprimido: equipamentos, instalação, auditoria e manutenção." />
  <meta property="og:type" content="website" />
  <meta property="og:image" content="<?= BASE ?>/assets/img/placeholder-hero.jpg" />
  <meta name="theme-color" content="#ffffff" />
  <script defer src="<?= BASE ?>/assets/js/main.js?v=<?= time() ?>"></script>
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "Arcompi Compressores",
  "image": "/arcompi_init/assets/img/placeholder-hero.jpg",
    "url": "https://www.arcompicompressores.com.br/",
    "telephone": "+55 45 3306-2850",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Rua Pio XII, 705",
      "addressLocality": "Cascavel",
      "addressRegion": "PR",
      "postalCode": "85801-210",
      "addressCountry": "BR"
    },
    "areaServed": "Paraná e região Sul",
    "priceRange": "$$"
  }
  </script>
</head>
