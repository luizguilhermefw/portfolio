<?php
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');

$ok = function($msg){ echo json_encode(['ok'=>true,'message'=>$msg]); exit; };
$err = function($msg, $code=400){ http_response_code($code); echo json_encode(['ok'=>false,'message'=>$msg]); exit; };

if($_SERVER['REQUEST_METHOD'] !== 'POST') $err('Método inválido',405);
if( empty($_POST['csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf']) ) $err('Sessão expirada. Atualize a página.');
if( !empty($_POST['website']) ) $ok('Recebido.'); // honeypot

$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$telefone = trim($_POST['telefone'] ?? '');
$assunto = trim($_POST['assunto'] ?? '');
$mensagem = trim($_POST['mensagem'] ?? '');

if(!$nome || !$email || !$assunto || !$mensagem) $err('Preencha os campos obrigatórios.');
if(!filter_var($email, FILTER_VALIDATE_EMAIL)) $err('E-mail inválido.');

$to = 'ziulprof@gmail.com';
$subject = 'Contato do site: '. $assunto;
$body = "Nome: $nome\nE-mail: $email\nTelefone: $telefone\nAssunto: $assunto\n\nMensagem:\n$mensagem\n";
$headers = [
  'From' => 'Site Arcompi <no-reply@seu-dominio.com.br>',
  'Reply-To' => $email,
  'Content-Type' => 'text/plain; charset=UTF-8'
];

$headers_str = '';
foreach($headers as $k=>$v){ $headers_str .= $k.': '.$v."\r\n"; }

if( mail($to, $subject, $body, $headers_str) ){
  $ok('Mensagem enviada com sucesso. Em breve entraremos em contato.');
} else {
  $err('Não foi possível enviar agora. Tente mais tarde.');
}
?>
