<?php
// Redireciona para a nova Home
header('Location: /arcompi_init/home', true, 302);
exit;
?>
